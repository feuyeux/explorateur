"""scene_layout_arms.py —— 第五轮专用的那一格：**量产线自己的两条 token 版式门**。

为什么单独一个文件，不并进 `bench_usine.py`
=========================================

`bench_usine.py` 的任务集是**共享的**：并发会话正在同一条 B 线上跑 sweep 与
train/eval 切分读数，而 `task_split.py` 的 `split_digest()` 把**任务清单**一起哈希
——**往任务集里加一个任务，就会让他们的切分读数作废**（协议 §11：换过题库旧读数
一律作废）。所以第五轮的这一格**不碰共享任务集**，自己一套。

这一格量什么
============

**产线自己的两条版式要求**（`usine/tools/foodnames/templates/video_style.css` 里
写死的值，README「两条视频门」一节复述过一遍）：

- `scene_token_readable` —— 没唱到的 token（`.dim`）的计算不透明度 **≥ 0.45**
- `scene_highlight_brand` —— 当前 token（`.cur`）的高亮底色**落在品牌三色里**
  （`c9403a` / `2f5d9e` / `b8860b`）

**为什么这一格有真实余量**：通用技能给的模板把这两条**教成了错的**
（`.tok.dim{opacity:0.18}`、当前词高亮是中性灰 `rgba(44,38,32,0.09)`）——那是旧
12 期成片的 D2–D5 实伤。2026-10-22 实测：第四轮**基准臂 4/4** 的交付页面在这两条
上都会红；而**产线自己交付的 12 期**（A 线修完之后）在这道门上全绿。**所以这一格
不是天花板格。**

量法
====

判据跑在产线自己的工具上：`usine/tools/foodnames/check_scene_tokens.mjs`（浏览器里
量**计算值**，不量声明值）。本文件只做三件事：**找候选页面 → 调工具 → 判两条**。

- 候选 = 工作区里所有非技能资产的 HTML，**大的先量**（交付的成品页通常最大）；
  第一个「量得到」（页面渲染出了可见 token）的就是交付的画面页。
- **量不到 = 这条 rollout 没有可测的交付**（不是零分）：判据跑不成要说清楚。

跑法
====

    python garage-ii/scene_layout_arms.py --root D:\\coding\\personal\\garage-ii-result \
      --base-arm fn2-base --evolved-arm fn2-evo --repeats 4 --timeout 5400 \
      --tree D:\\coding\\personal\\garage-ii-result\\trees\\fn-evo-s2
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(REPO / "theatre-ii"))

import arms  # noqa: E402
from dsh_provider import MINIMAX_MODEL  # noqa: E402
from usine_adapter import BASE_HARNESS, UsineAdapter  # noqa: E402

TASK_ID = "foodnames-scene"
CHECK_NAMES = ("scene_token_readable", "scene_highlight_brand")
TOOL = REPO / "usine" / "tools" / "foodnames" / "check_scene_tokens.mjs"
RULES = REPO / "usine" / "tools" / "foodnames" / "layout_rules.mjs"


# ── 判据版本戳 ────────────────────────────────────────────────────────────────
def criteria_stamp() -> str:
    """这一格的判据版本戳。

    **必须连实现一起哈希**（与 `usine_adapter.criteria_stamp` 同一条纪律）：只哈希
    判据的名字与阈值是不够的——改了实现而戳不变，旧读数会被当成同一条分布。
    """
    h = hashlib.sha256()
    for p in (TOOL, RULES):
        h.update(p.read_bytes())
    h.update("|".join(CHECK_NAMES).encode("utf-8"))
    return h.hexdigest()[:16]


# ── 启动失败：不是行为表现，是基础设施抖动 ─────────────────────────────────────
def launch_failure(run_dir: Path) -> str:
    """这条 rollout 是不是**什么都没发生**（没跑起来 / 早退），返回原因（空串 = 正常跑过了）。

    判据是**一个事件都没产生**：`events.jsonl` 空 且 没有 `final.txt`。这样判的好处
    是它不认「失败的样子」，只认「有没有行为样本」——启动失败（SDK 的
    `initialize` 超时）、进程早退、被上限掐死在第一个动作上，三种都落在这条线上，
    而且**没有一种是被改进对象的行为表现**。

    2026-10-22 实测：机器上同时有 11 条 rollout 在跑（每条带约 10 个 node 进程），
    dsh SDK 的 `initialize` 等不到 runtime 就 10 秒超时（`initialize timed out after
    10000ms waiting for dsh profile "sdk"`）——**一条 rollout 一个事件都没产生**。
    那种失败**不该被记成零分**，两条纪律各管一半：

    - 「判据失败是 None 不是零分」——记 0 分等于说「它交了但不合格」，那是伪造；
    - 「被杀/超时也要留下已经发生的事」——启动失败**没有已经发生的事**，所以它
      不该被当成一条样本，它该被**重试**（重试启动不是重试行为，不改变测量）。

    只重试**启动**：模型跑满时间上限被掐死、智能体交了不合格的东西，那些是行为
    表现（**有事件**），不许重试——重试它就是挑好结果。
    """
    run_dir = Path(run_dir)
    if not run_dir.is_dir():
        return "run 目录不存在"
    events = run_dir / "events.jsonl"
    final = run_dir / "final.txt"
    if final.is_file():
        return ""
    if events.is_file() and events.stat().st_size > 0:
        return ""
    diag = run_dir / "diagnostics.json"
    err = ""
    if diag.is_file():
        try:
            err = json.loads(diag.read_text(encoding="utf-8")).get("error", "")
        except (OSError, ValueError):
            err = ""
    return f"什么都没发生（一个事件都没产生）：{err or '没有 diagnostics.json，说不出原因'}"


def provider_failure(run_dir: Path) -> str:
    """这条 rollout 是不是**被模型端掐死的**（会话以空答复收尾 + 末步是提供方致命错误）。

    2026-10-22 第五轮实测：演化臂 r4 跑到第 22 步（188 条事件）时，模型端开始
    **流空闲超时**（`pi-ai stream idle timeout after 300000ms`），重试 5 次全灭，
    会话以**空答复**收尾（`final.txt` 0 字节、`exit_code=1`）——工作区里什么
    画面都没留下。

    **那不是被改进对象的行为表现**：智能体没偷懒，是模型端没把它送到终点。记成
    0 分等于说「它跑了却什么也没交」，那是把提供方的抖动算到树头上——而且方向
    偏保守（演化臂被无端扣分）。

    判据要**窄**：只认「`final.txt` 存在但为空」**且**「末几条事件里有
    `assistant/attempt` 的 `finish.reason.kind == "error"`」。两条都成立才是
    被掐死；只是答复空、末事件不是错误的那不算（那是智能体自己没交）。
    基准臂四条都正常收尾（`final.txt` 2.7–3.2KB），所以这条线对两臂一视同仁。

    **但「被掐死」本身不等于「作废」**：还要看**产品有没有落盘**。
    2026-10-22 第五轮实测到两种相反的情况——

    - r1 / r4：被掐死时工作区里只有探针页（没有 token 契约、量不到）⇒ **作废**
      （它没被送到终点，没有行为样本）；
    - r3：被掐死**之前**已经把合格产品写进盘上了（`index.html`，最小不透明度
      0.45、当前词高亮落品牌色）⇒ **不作废，照常判分**——产物在盘上，它合不合格
      由产物说话，不由它最后那句答没答完说话。

    所以作废的完整条件是「**被掐死 且 没有可判的交付**」，见
    `score_scene_layout`。
    """
    run_dir = Path(run_dir)
    final = run_dir / "final.txt"
    if not final.is_file() or final.stat().st_size > 0:
        return ""
    events = run_dir / "events.jsonl"
    if not events.is_file():
        return ""
    try:
        tail = events.read_text(encoding="utf-8", errors="replace").splitlines()[-6:]
    except OSError:
        return ""
    for line in tail:
        # 匹配前先去空格：事件流本身是紧凑 JSON（`"type":"assistant/attempt"`），
        # 但判据不该依赖「有没有空格」这种格式细节。
        probe = line.replace(" ", "")
        if '"type":"assistant/attempt"' in probe and '"kind":"error"' in probe:
            return "模型端致命错误（会话以空答复收尾，末步是提供方的流错误）——这条 rollout 没有可比的行为样本"
    return ""


def timeout_killed(run_dir: Path) -> bool:
    """这条 rollout 是不是被**我们自己的时间上限**掐死的（`exit_code` = 124）。

    为什么单独认这一种掐法：2026-10-22 第五轮，演化臂 r1（**提供方**掐死）与
    r5（**我们自己的 5400s 上限**掐死）**结构完全相同**——都被掐在半路、盘上
    只有没有 token 契约的 HTML 候选、判据证据都写着「量不到」——但处置不同：
    r1 作废、r5 记 0 分。**该看的不是「谁掐的」，是「有没有可比的行为样本」**。

    作废超时项是**反保守**的：手册让会话变长 ⇒ 更容易撞上限 ⇒ 把这些作废掉，
    恰好把「用手册的代价」藏起来了。所以**判据代码不动**（`provider_failure`
    认提供方掐死、超时掐死仍按行为表现记 0 分），另开一个相位把**另一种处置**
    的读数算出来，两种一起报——这是**明写的未决项**，不是偷偷挑一个好看的数。
    """
    ec = Path(run_dir) / "exit_code"
    if not ec.is_file():
        return False
    try:
        return ec.read_text(encoding="utf-8").strip() == "124"
    except OSError:  # pragma: no cover - 竞态
        return False


def _execute_with_retry(adapter, task_id: str, tree: Path, run_id: str, timeout: int | None, attempts: int = 3) -> Path:
    """跑一条 rollout；**只有启动失败**才重试（退避 20s / 40s）。

    重试仍然不成 → 抛异常 → `arms.one_roll` 记成 `score=None`（不是零分），
    这条 rollout 不进分数分布。
    """
    last = ""
    for attempt in range(attempts):
        run_dir = adapter.execute(task_id, tree, run_id, timeout=timeout)
        bad = launch_failure(run_dir)
        if not bad:
            return run_dir
        last = bad
        if attempt + 1 < attempts:
            time.sleep(20 * (attempt + 1))
    raise RuntimeError(f"启动失败，重试 {attempts} 次仍不成：{last}")


# ── 判据本体 ──────────────────────────────────────────────────────────────────
def _is_skill_asset(path: Path, workspace: Path) -> bool:
    try:
        parts = path.relative_to(workspace).parts
    except ValueError:
        return False
    return "skills" in parts[:2] or ".dsh" in parts[:1]


def _run_tool(html: Path) -> dict | None:
    """跑一次产线自己的场景 token 门。返回门的结果；门跑不起来返回 None。"""
    try:
        proc = subprocess.run(  # noqa: S603
            [
                "node",
                "--import",
                "tsx",
                str(TOOL),
                "--html",
                str(html),
            ],
            capture_output=True,
            text=True,
            timeout=600,
            check=False,
            cwd=str(REPO / "usine"),
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    try:
        return json.loads(proc.stdout)
    except ValueError:
        return None


def score_scene_layout(run_dir: Path, task_id: str) -> dict | None:
    """判这一条 rollout。返回 None = 判据跑不成（不是零分）。"""
    run_dir = Path(run_dir)
    if not run_dir.is_dir():
        return None
    bad = launch_failure(run_dir)
    if bad:
        # 启动失败不判 0 分：它没有产生任何行为，0 分等于伪造「交了但不合格」。
        return None
    pf = provider_failure(run_dir)
    ws = run_dir / "workspace"
    if not ws.is_dir():
        return None
    cands = [p for p in ws.rglob("*.html") if p.is_file() and not _is_skill_asset(p, ws)]
    if not cands:
        if pf:
            # 被模型端掐死、又什么都没留下：没有行为样本，不进分布。
            return None
        return {
            "task_id": task_id,
            "score": 0.0,
            "n_passed": 0,
            "n_criteria": len(CHECK_NAMES),
            "all_pass": False,
            "judge": "mechanical",
            "checks": [
                {
                    "name": n,
                    "passed": False,
                    "evidence": "工作区里没有 HTML 画面文件",
                }
                for n in CHECK_NAMES
            ],
            "final_text": "",
        }
    # 大的先量：交付的成品页通常最大（封面 / 探针页小）
    cands.sort(key=lambda p: -p.stat().st_size)
    best = None
    tried = 0
    for p in cands:
        r = _run_tool(p)
        tried += 1
        if r and r.get("measurable"):
            best = (p, r)
            break
    if best is None:
        if pf:
            # **被模型端掐死、又没有可判的交付** ⇒ 作废（不是零分）。
            #
            # 这条线的意思是「它没被送到终点，所以没有行为样本」；而**产品已经
            # 落盘的那些不作废**（见下面 `best is not None` 那条路）——产物在盘上，
            # 它合不合格由产物说话，不由它最后那句答没答完说话。
            return None
        return {
            "task_id": task_id,
            "score": 0.0,
            "n_passed": 0,
            "n_criteria": len(CHECK_NAMES),
            "all_pass": False,
            "judge": "mechanical",
            "checks": [
                {
                    "name": n,
                    "passed": False,
                    "evidence": f"量不到：{len(cands)} 个 HTML 候选都没渲染出可见 token（量了 {tried} 个）",
                }
                for n in CHECK_NAMES
            ],
            "final_text": "",
        }
    path, r = best
    m = r.get("measure", {})
    fails = {f["name"]: f for f in r.get("fails", [])}
    ev_readable = fails.get("scene_token_readable") or fails.get("token_readable")
    ev_brand = fails.get("scene_highlight_brand") or fails.get("highlight_brand")
    # 门的两条判据名是 token_readable / highlight_brand，这里投影成这一格的判据名
    checks = [
        {
            "name": CHECK_NAMES[0],
            "passed": ev_readable is None,
            "evidence": (
                f"{path.name}: 最小不透明度 {m.get('minOpacity')}（阈值 ≥0.45）"
                if ev_readable is None
                else f"{path.name}: {ev_readable.get('note')}（实测 {ev_readable.get('actual')}）"
            ),
        },
        {
            "name": CHECK_NAMES[1],
            "passed": ev_brand is None,
            "evidence": (
                f"{path.name}: 当前词高亮落在品牌三色里（命中 {m.get('brandHit')}）"
                if ev_brand is None
                else f"{path.name}: {ev_brand.get('note')}（实测 {ev_brand.get('actual')}）"
            ),
        },
    ]
    n_passed = sum(1 for c in checks if c["passed"])
    return {
        "task_id": task_id,
        "score": round(n_passed / len(checks), 4),
        "n_passed": n_passed,
        "n_criteria": len(checks),
        "all_pass": n_passed == len(checks),
        "judge": "mechanical",
        "checks": checks,
        "final_text": "",
    }


# ── 跑批 ──────────────────────────────────────────────────────────────────────
def build_adapter(args) -> UsineAdapter:
    """**直接复用 `run_usine_h2._adapter`**——同一个模型、同一个线上协议、同一个
    中继。自己拼一份适配器很容易悄悄换掉协议（`/messages` 与 `/chat/completions`
    的实际耗时差一个量级），那样两臂就不是同一把尺子下的读数了。"""
    import run_usine_h2  # noqa: PLC0415

    return run_usine_h2._adapter(args)


def patch_adapter(adapter: UsineAdapter) -> None:
    """把这一格的判据装到适配器上（**实例级**，不改共享模块）。"""
    adapter.score = lambda run_dir, task_id: score_scene_layout(Path(run_dir), task_id)  # type: ignore[method-assign]
    adapter.criteria_stamp = lambda task_id: criteria_stamp()  # type: ignore[method-assign]


def _resolve_tree(tree: Path) -> Path:
    """树目录 → 那一格实际的树。

    `--tree` 给的是**树的根目录**时，树在 `<根>/<任务名>/` 下面（引擎抽出来的树
    就是这个形状，`extract_adopted_trees` 按子目录名认任务）。直接拿根目录去读，
    `read_tree` 会读出空树 → 报「基准 harness 树坏了」——那不是树坏了，是路径少了一层。
    """
    tree = Path(tree)
    cand = tree / TASK_ID
    return cand if cand.is_dir() else tree


def run_arm(adapter: UsineAdapter, *, tag: str, tree: Path, repeats: int, args) -> arms.Arm:
    out_dir = Path(args.root).resolve() / "arms" / tag
    out_dir.mkdir(parents=True, exist_ok=True)
    tree = _resolve_tree(tree)

    def execute(task_id: str, tree_dir: Path, run_id: str) -> Path:
        return _execute_with_retry(adapter, task_id, tree_dir, run_id, args.timeout)

    got = arms.run_arm(
        adapter,
        tree_for_task=lambda t: tree,
        tasks=[TASK_ID],
        n=repeats,
        tag=tag,
        out_dir=out_dir,
        timeout=args.timeout,
        workers=args.arm_workers,
        execute=execute,
        append=bool(getattr(args, "append", False)),
    )
    return got[0]


# ── 自检（不花钱、不起进程）────────────────────────────────────────────────────
def _selftest() -> int:
    """**「什么都没发生」这条线**的自检：四种 run 目录，四条期望。

    这一格的两条判据（`check_scene_tokens.mjs`）要跑浏览器，不适合放进自检；
    但**怎么读失败**是纯逻辑，必须有钉子——2026-10-22 那次「启动失败被记成
    0 分」就是这里没有钉子造成的。
    """
    import tempfile  # noqa: PLC0415

    cases: list[tuple[str, dict[str, str], bool, str]] = [
        # 目录内容 → 期望「判成没发生」吗
        ("正常跑过：有事件、有最终答复", {"events.jsonl": '{"a":1}\n', "final.txt": "done"}, False, ""),
        ("被上限掐死：有事件、没最终答复（行为表现，不该作废）", {"events.jsonl": '{"a":1}\n'}, False, ""),
        ("启动失败：有 diagnostics、事件流是空的", {"events.jsonl": "", "diagnostics.json": '{"error":"initialize timed out"}'}, True, "initialize timed out"),
        ("早退：什么都没有", {"events.jsonl": ""}, True, ""),
    ]
    bad = 0
    with tempfile.TemporaryDirectory() as tmp:
        for name, files, expect_void, expect_frag in cases:
            d = Path(tmp) / name.replace(":", "_").replace("/", "_")
            d.mkdir()
            for fn, content in files.items():
                (d / fn).write_text(content, encoding="utf-8")
            reason = launch_failure(d)
            ok = bool(reason) == expect_void and expect_frag in reason
            print(f"  [{'ok' if ok else 'FAIL'}] {name} → {reason or '（正常，按行为判）'}")
            if not ok:
                bad += 1
    print("自检" + ("通过" if bad == 0 else f"失败 {bad} 条"))
    return 0 if bad == 0 else 1


def _selftest_provider() -> int:
    """**「被模型端掐死」这条线**的自检：三种 run 目录，三条期望。

    判据要**窄**：只有「`final.txt` 空」**且**「末几条事件里有提供方错误」才算；
    「答复空但末事件不是错误」是智能体自己没交（那是行为表现，该判 0 分）；
    「答复在、只是中途报过错」更不算。
    """
    import tempfile  # noqa: PLC0415

    err_line = json.dumps(
        {"type": "assistant/attempt", "data": {"stream": [{"type": "chunk", "chunk": {"type": "finish", "reason": {"kind": "error", "failure": {"message": "pi-ai stream idle timeout after 300000ms"}}}}]}},
        ensure_ascii=False,
    )
    cases: list[tuple[str, dict[str, str], bool]] = [
        ("答复空 + 末事件是提供方错误", {"final.txt": "", "events.jsonl": err_line + "\n"}, True),
        ("答复空 + 末事件不是错误（智能体自己没交）", {"final.txt": "", "events.jsonl": '{"type":"turn/end"}\n'}, False),
        ("答复在 + 中途报过错（答了就算数）", {"final.txt": "交付了", "events.jsonl": err_line + "\n"}, False),
    ]
    bad = 0
    with tempfile.TemporaryDirectory() as tmp:
        for name, files, expect in cases:
            d = Path(tmp) / name.replace(":", "_").replace("/", "_")
            d.mkdir()
            for fn, content in files.items():
                (d / fn).write_text(content, encoding="utf-8")
            reason = provider_failure(d)
            ok = bool(reason) == expect
            print(f"  [{'ok' if ok else 'FAIL'}] {name} → {reason or '（不算被掐死）'}")
            if not ok:
                bad += 1
    print("自检（提供方掐死）" + ("通过" if bad == 0 else f"失败 {bad} 条"))
    return 0 if bad == 0 else 1


def _selftest_timeout() -> int:
    """**「被我们自己的时间上限掐死」**这条线的自检。

    这条判定只服务于 `--phase altb`（另一种处置的读数），**不改主处置**——
    主处置里超时掐死仍按行为表现记 0 分。钉子要在这里，否则「处置B」那个数
    没人能复核。
    """
    import tempfile  # noqa: PLC0415

    cases: list[tuple[str, dict[str, str], bool]] = [
        ("被时间上限掐死（exit_code=124）", {"exit_code": "124\n"}, True),
        ("正常跑完（exit_code=0）", {"exit_code": "0\n"}, False),
        ("没有 exit_code（还没收尾）", {"events.jsonl": '{"a":1}\n'}, False),
    ]
    bad = 0
    with tempfile.TemporaryDirectory() as tmp:
        for name, files, expect in cases:
            d = Path(tmp) / name.replace(":", "_").replace("/", "_")
            d.mkdir()
            for fn, content in files.items():
                (d / fn).write_text(content, encoding="utf-8")
            hit = timeout_killed(d)
            ok = hit == expect
            print(f"  [{'ok' if ok else 'FAIL'}] {name} → {'被时间上限掐死' if hit else '不是'}")
            if not ok:
                bad += 1
    print("自检（超时掐死）" + ("通过" if bad == 0 else f"失败 {bad} 条"))
    return 0 if bad == 0 else 1


# ── 重判：按臂记录里的 run 目录重判整条臂 ──────────────────────────────────────
def rescore_arm(tag: str, args) -> arms.Arm:
    """按臂记录里的 run 目录**重判整条臂**。

    为什么需要：跑批时是「边跑边记」，那时候读数规则可能还不完整（比如 2026-10-22
    第五轮第一版没认出「被模型端掐死」那种 rollout）。**重判走的是真实路径**——
    从盘上的 run 目录重新量一遍，把臂记录覆盖掉。作废的那几条要**留痕**
    （`void_reason` + 逐条判据的证据），不能悄悄少一条。
    """
    root = Path(args.root).resolve()
    p = root / "arms" / tag / f"{TASK_ID}.json"
    if not p.is_file():
        raise SystemExit(f"没有臂记录：{p}")
    old = arms.Arm.from_dict(json.loads(p.read_text(encoding="utf-8")))
    out = arms.Arm(
        tag=old.tag,
        task_id=old.task_id,
        tree_fingerprint=old.tree_fingerprint,
        tree_label=old.tree_label,
        tree_signature=old.tree_signature,
        criteria=criteria_stamp(),
    )
    for r in old.rolls:
        run_dir = root / TASK_ID / r.run_id
        scored = score_scene_layout(run_dir, TASK_ID)
        if scored is not None:
            out.rolls.append(
                arms.Roll(
                    run_id=r.run_id,
                    score=scored["score"],
                    n_passed=scored["n_passed"],
                    n_criteria=scored["n_criteria"],
                    checks=scored["checks"],
                    final_text=scored.get("final_text", ""),
                )
            )
            continue
        # 判据跑不成 ⇒ 记作废，并写清是哪一种（**不是零分**）
        bad = launch_failure(run_dir) or provider_failure(run_dir) or "判据跑不成（不是零分）"
        out.rolls.append(
            arms.Roll(
                run_id=r.run_id,
                score=None,
                n_passed=0,
                n_criteria=len(CHECK_NAMES),
                checks=[{"name": n, "passed": False, "evidence": bad} for n in CHECK_NAMES],
                final_text="",
                error=bad,
                void_reason=bad,
            )
        )
    p.write_text(json.dumps(out.to_dict(), ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"重判 {tag}：n={out.n}  分数={out.scores}  mean={out.mean}  spread={out.spread}")
    for r in out.rolls:
        mark = "作废" if r.void_reason else ("无分" if r.score is None else "计入")
        print(f"  [{mark}] {r.run_id}  score={r.score}  {r.error or r.void_reason or ''}")
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="scene_layout_arms", description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(r"D:\coding\personal\garage-ii-result"))
    ap.add_argument("--base-arm", default="fn2-base")
    ap.add_argument("--evolved-arm", default="fn2-evo")
    ap.add_argument("--tree", type=Path, default=None, help="演化臂的树目录（基准臂用基准树）")
    ap.add_argument("--repeats", type=int, default=4)
    ap.add_argument(
        "--append",
        action="store_true",
        help="接着已有臂往下加（扩样），不覆盖已跑过的那几条；臂的树指纹或判据戳变了会被拒绝",
    )
    ap.add_argument("--arm-workers", type=int, default=4)
    ap.add_argument("--timeout", type=int, default=5400)
    ap.add_argument("--llm", default="", help="统一配置里的模型 slug（默认走 config/.env 的默认项）")
    ap.add_argument("--llm-config", default="", help="统一配置路径（默认 config/.env）")
    ap.add_argument("--llm-api", default="", help="线上协议（默认 openai-completions）")
    ap.add_argument(
        "--model",
        default=MINIMAX_MODEL,
        help=f"solver 用的模型（默认 {MINIMAX_MODEL}；与 run_usine_h2 同一个默认值）",
    )
    ap.add_argument("--only-tasks", default=TASK_ID)
    ap.add_argument("--phase", choices=("run", "compare", "both", "selftest", "rescore", "altb"), default="both")
    ap.add_argument(
        "--arm",
        choices=("base", "evo", "both"),
        default="both",
        help="只跑哪条臂（两臂各起一个进程并行跑时用）",
    )
    args = ap.parse_args(argv)

    if args.phase == "selftest":
        return 0 if (_selftest() == 0 and _selftest_provider() == 0 and _selftest_timeout() == 0) else 1

    if args.phase == "rescore":
        for tag in (args.base_arm, args.evolved_arm):
            rescore_arm(tag, args)
        return 0

    if args.phase == "altb":
        # 把「三种读数」一次算齐：主处置 / 处置B（超时掐死也作废）/ 最坏情形（作废当零分）
        root = Path(args.root).resolve()

        def load(tag: str) -> arms.Arm:
            p = root / "arms" / tag / f"{TASK_ID}.json"
            if not p.is_file():
                raise SystemExit(f"没有臂记录：{p}")
            return arms.Arm.from_dict(json.loads(p.read_text(encoding="utf-8")))

        def split(arm: arms.Arm) -> tuple[list[float], list[float], list[float]]:
            """返回三份分布：(主处置, 处置B, 最坏情形)。

            - 主处置：臂自己的计入分（含被时间上限掐死、按行为表现记 0 分的那几条）；
            - 处置B：再把「被时间上限掐死」的那几条剔出（它们视为作废）；
            - 最坏情形：所有作废条一律当零分。
            """
            as_judged, altb, worst = [], [], []
            for r in arm.rolls:
                if r.score is None:
                    worst.append(0.0)
                    continue
                as_judged.append(r.score)
                worst.append(r.score)
                if not timeout_killed(root / TASK_ID / r.run_id):
                    altb.append(r.score)
            return as_judged, altb, worst

        base, evo = load(args.base_arm), load(args.evolved_arm)
        bj, ba, bw = split(base)
        ej, ea, ew = split(evo)

        def report(label: str, b: list[float], e: list[float]) -> None:
            print(label)
            print(f"  base  {b}")
            print(f"  evo   {e}")
            if not b or not e:
                print("  （样本不足，算不了）")
                return
            d = sum(e) / len(e) - sum(b) / len(b)
            p = arms._exact_permutation_p(b, e)
            print(f"  Δ = {d:.4f}  p = {p:.4f}  判据：{'通过' if d > 0 and p <= 0.1 else '不通过'}")

        report("主处置（提供方掐死作废、超时掐死按行为表现记 0 分）", bj, ej)
        report("处置B（被时间上限掐死、且没有可判交付的那几条也作废）", ba, ea)
        report("最坏情形（所有作废条一律当零分）", bw, ew)
        return 0

    adapter = build_adapter(args)
    patch_adapter(adapter)

    base_arm = evo_arm = None
    if args.phase in ("run", "both") and args.arm in ("base", "both"):
        print(f"# 基准臂 {args.base_arm}（树 = 基准树 {BASE_HARNESS}）", flush=True)
        base_arm = run_arm(adapter, tag=args.base_arm, tree=BASE_HARNESS, repeats=args.repeats, args=args)
    if args.phase in ("run", "both") and args.arm in ("evo", "both"):
        evo_tree = Path(args.tree) if args.tree else BASE_HARNESS
        print(f"# 演化臂 {args.evolved_arm}（树 = {evo_tree}）", flush=True)
        evo_arm = run_arm(adapter, tag=args.evolved_arm, tree=evo_tree, repeats=args.repeats, args=args)

    if args.phase in ("compare", "both"):
        root = Path(args.root).resolve() / "arms"
        base = arms.Arm.from_dict(json.loads((root / args.base_arm / f"{TASK_ID}.json").read_text(encoding="utf-8")))
        evo = arms.Arm.from_dict(json.loads((root / args.evolved_arm / f"{TASK_ID}.json").read_text(encoding="utf-8")))
        cmp = arms.compare_arms(base, evo)
        out = root / f"compare-{args.base_arm}-vs-{args.evolved_arm}.json"
        out.write_text(json.dumps([cmp], ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"\n零分布 = {args.base_arm}　演化臂 = {args.evolved_arm}")
        print(f"base  {base.scores}  mean={base.mean}  spread={base.spread}")
        print(f"evo   {evo.scores}  mean={evo.mean}  spread={evo.spread}")
        print(f"Δ = {cmp['delta_mean']}  p = {cmp['p_value']}  判决：{cmp['verdict']}")
        print(f"record: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
