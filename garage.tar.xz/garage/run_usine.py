#!/usr/bin/env python3
"""run_usine.py — orchestrate RSI waves over the usine production line.

Phase-1 wave loop for the usine (feuille) multilingual video production line,
adapted onto the worktree substrate through garage/{guest_env,
verifier_adapter,usine_hooks,wave_merge}.py.  Two hosts can drive it: the
Windows wave host (git-bash + subst drives) and POSIX dev hosts such as this
Mac (bash + scratch-disk prefix; guest_env/verifier_adapter branch on
os.name with the Windows code path byte-identical).  The stock wave
machinery (explore/phase1_wave.py) is reused untouched; this orchestrator
only assembles the adaptation layer around it.

Assembly contract (order is load-bearing)
-----------------------------------------
1.  Locate the théâtre checkout and put it (plus this directory) on sys.path.
2.  install_verifier_adapter() BEFORE any core/explore import: production
    construction sites resolve the executor and system-prompt builder from
    core.verifier_runtime at call time.
3.  Patch core.actor.build_system / core.loop.build_system (dual-module, ALE
    precedent) with substrate-true replacements + a transport note.  The patch
    asserts every seam substring against BOTH stock variants (native/blind)
    at install time, so upstream template drift fails loudly instead of
    silently no-op'ing.
4.  Load the five usine role configs (config/roles-usine/*.yaml), normalize
    the deferred verifier-config paths against THIS directory, and validate
    the decided model lineup fail-closed (no model outside the approved
    slugs; escalated seats recomputed exactly like core.loop.escalation_cfg).
5.  Resolve LLM endpoints IN MEMORY from the host credential store
    (provider.* then custom_provider.*; apiKey/baseURL per provider options).
    Key values never enter logs, manifests, or errors.
6.  Preflight prints a readiness payload and writes NOTHING (no endpoints
    file, no run root, no corpus).  Execute requires the exact ack token.
7.  The run root lives OUTSIDE every repository; endpoints.json is generated
    there and pointed at via RSIAGENT_LLM_ENDPOINTS_FILE before any LLM call.
8.  Fresh runs build the instruction corpus from the distribution; resumes
    merge pending waves, then require the corpus to EQUAL a fresh rebuild
    from the distribution.  The corpus is FIXED for the whole run: stock
    Phase 1 feeds every prior project text verbatim back into later
    Curriculum prompts (previous_wave_outcomes -> _outcome_text) while
    _audit_prompt authorizes only the target direction, so any mid-run
    corpus growth would trip the boundary at the next wave's FIRST
    authoring segment.
9.  Before anything is written or spent, _check_distribution_fences proves
    the distribution's 8-gram shingles are DISJOINT from every text that
    can reach an audited surface: seeded usine tracked text and capture
    member names, the first-party prompt/infra modules
    (explore/core/env/config/llm), this adapter directory (the transport
    note), and the role configs' system_extra.  The stock audit exempts
    only the target direction (wave prompts) or the project instruction
    (captures) - never the distribution - so one shared shingle would trip
    audits on every wave.  Both entrypoints and every resume run the gate
    (resume re-runs it after pending merges, since HEAD moved); a
    collision means the distribution wording must change, never the fence.
10. Fixtures are seeded additively at the capture seam: the first
    ``phase1-project-*`` capture of each wave pushes a git-archive(HEAD) seed
    of the usine prefix into the guest and extracts it over /home/user
    (baseline wins collisions; the Curriculum scaffold is preserved), and the
    captured fixture — the merge baseline — becomes scaffold UNION baseline.
    The DRS's serial core needs the SAME seam under its OWN key
    (``ep<N>-fixtures``): it resets the guest between seats, and that reset
    takes the seeded tree with it, so a DRS Actor whose capture seam did not
    re-seed would find ONLY the Curriculum's fixture files in its owned root
    — no repository to edit (measured 2026-10-20, bfs16h).  A replay guard
    then fails closed if the tree handed to the Actor carries no baseline.
    Candidate captures (``phase1-candidate-*``) and blocked-draft captures
    are never seeded.  Every capture (fixture and candidate alike) prunes the
    regenerable heavy directories (node_modules, dist: _CAPTURE_EXCLUDE_PARTS
    -> provisioning exclude_parts, unanchored at any depth) — what capture
    never picks up, wave_merge.EXCLUDED_PARTS never tries to merge back, and
    the leakage audit never has to scan.
11. Every completed wave merges into the real usine repository through the
    wave-merge event sink (one commit per accepted candidate, one tag per
    wave).  Merged delta paths keep the executable bit when the candidate
    archive carried it or git already tracks the path as 100755
    (bin/feuille.js is the anchor).  The gate ("pnpm verify") runs BEFORE the
    commit; a green merge rebuilds the gitignored dsh-plugin dist/index.mjs,
    so an accepted improvement reaches the `dsh web --patch`-loaded agent
    surface without any extra plumbing.  Publishing stays impossible: the
    VM facade refuses publish-shaped programs before execution.
12. Gate-runnability preflight (gate_preflight) runs on BOTH entrypoints
    before a single token is spent: the gate command must resolve on PATH
    (a Windows .cmd/.bat shim is rejected — the merge spawns the gate with
    shell=False and CreateProcess cannot run shims; install standalone
    pnpm), pnpm-shaped gates need Node >= 24 and pnpm >= 11 plus a
    package.json and an installed tree (--gate-install opts into running
    `pnpm install --frozen-lockfile --prefer-offline`; the read-only
    --preflight report never installs).  A red gate at merge time is a
    data-level gate_rejected — silent total candidate loss — so an
    unrunnable gate must die here, before the wave.
13. The seeded guest is probed once for its toolchain (node/pnpm versions)
    fail-closed before waves spend anything on a guest that cannot even
    attempt the gate.

Improvement directions: the distribution sanctions BOTH the operator-facing
pipeline and the agent surface (the dsh plugin package: tool descriptions,
request schemas, discipline/refusal/approval wording, and the skills howtos
that teach the same surface) — with the guard machinery pinned: approval-gated
tools keep failing closed, publishing stays unreachable by default, and the
red-line/parity suites may be extended but never relaxed.

Wave-host readiness checklist (SKIP is not PASS — run the checklist on the
host that will drive the wave, before the first real wave there):

Both hosts additionally require the harness ``link:`` anchor: a
``deepseek-harness`` checkout five levels above the usine tree (what the
dsh-plugin ``link:`` devDependencies resolve against:
``vendor/cordis`` + ``packages/core/tools``).  The guest copy of the
tree is deeper, so the VM factory (``_harness_staging_vm_factory``)
stages the harness checkout root as a single symlink at every guest
disk root (a copy breaks the checkout's internal symlink closure; the
worktree guest is a path-REWRITE illusion, not an OS sandbox - guest
programs already resolve any absolute host path, and the publish/login
red lines are enforced by the VM facade and gates, not filesystem
isolation); without the real checkout to link to, guest creation fails
closed BEFORE any token is spent (every wave would be structurally
doomed to a gate-red typecheck).

Windows wave host:
  * toolchain: standalone pnpm.exe (NOT an npm shim) + Node >= 24 on PATH,
    warm pnpm store or network for the first install; GNU coreutils inside
    the guest (sha256sum/stat -c for capture replay).
  * smokes (theâtre venv, PowerShell): smoke_verifier_adapter.py,
    smoke_guest_env.py — plus re-running the POSIX-runnable set
    (wave_merge / usine_hooks / distribution_fence) and the provisioning
    engine tests, whose 3 broken-symlink replay cases need GNU coreutils.
    (smoke_dry_run_wave.py was retired 2026-10-19 by user decision:
    real waves only.)
  * probe_env.py for the guest-side node/pnpm probe.
  * first real wave: only on explicit user go ("喊跑才跑").

POSIX dev host (macOS), same loop through the POSIX substrate branch:
  * toolchain: brew coreutils (the guest PATH gets the gnubin overlay;
    guest_env fails closed without GNU stat/timeout) + the gnubin export
    in ~/.bash_profile for bash login shells (engine replay tests run
    bash -lc and macOS path_helper demotes a mere PATH prefix),
    standalone pnpm + Node >= 24 on PATH (pnpm must not be an npm shim).
  * smokes (théâtre venv): the two substrate smokes
    (smoke_guest_env / smoke_verifier_adapter) plus
    the POSIX-runnable set and the provisioning engine tests — with
    coreutils installed the 3 broken-symlink replay cases pass here too.
  * probe_env.py remains Windows-specific; the POSIX guest toolchain probe
    is the in-seed node/pnpm check run_usine does itself.
  * first real wave: only on explicit user go ("喊跑才跑").

Red lines: zero live platform publishing/login (three layers: VM facade,
guest-home USERPROFILE/HOME pin, offline-only gates); one commit per accepted
candidate; every wave tagged theatre/wave-N; no push; zero H3/mcode-tools
credit-spending calls outside an explicit per-call human approval.
"""

from __future__ import annotations

import argparse
import copy
import dataclasses
import gzip
import hashlib
import io
import json
import logging
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tarfile
import threading
import time
from pathlib import Path, PurePosixPath
from types import SimpleNamespace

log = logging.getLogger("rsiagent.usine.run")

_HERE = Path(__file__).resolve().parent
_EXPLORATEUR_ROOT = _HERE.parents[0]
DEFAULT_THEATRE = _EXPLORATEUR_ROOT / "théâtre"
DEFAULT_USINE_DIR = _EXPLORATEUR_ROOT / "usine"
# 运行产物落位（AGENTS.md「运行产物落位」）：**仓库外**、且与 harness2 线路分开——
#   RSIAgent（théâtre + garage）      → <explorateur 的同级>/garage-result
#   harness2（theatre-ii + garage-ii） → <explorateur 的同级>/garage-ii-result
# 仓库外是硬约束（dsh 的 project root 判定会让仓库内的 `.dsh/skills` 判到仓库根，
# 候选技能一个都扫不到，且**不报错**）；分线落位是硬约束（两线的读数必须能分开翻账）。
DEFAULT_RUNS_ROOT = (_EXPLORATEUR_ROOT.parents[0]
                     / "garage-result")
DEFAULT_LLM_CONFIG = _EXPLORATEUR_ROOT / "config" / ".env"
DEFAULT_DISTRIBUTION = _HERE / "distribution-usine.md"
# TS 迁移（usine P0-P8）后的门禁：pnpm verify（typecheck + vitest 全量）。
# 真 wave 跑之前须在驱动宿主（Windows wave host 或 POSIX 宿主）落实的前置条件：
# Node >= 24 + pnpm 11（Windows 上须 standalone 安装，.cmd shim 会被 merge 的
# 无 shell subprocess 拒掉）；首跑 pnpm install 需网络（或暖 pnpm store）；
# POSIX 宿主另需 brew coreutils（guest PATH 走 gnubin overlay）。node_modules/
# dist 落树内——capture 与合并两侧现已对称剪枝（provisioning.exclude_parts +
# wave_merge.EXCLUDED_PARTS），门禁可跑性由 gate_preflight 在花任何额度之前
# fail-closed 预检（真 wave 仍喊跑才跑）。
DEFAULT_GATE_ARGV = ("pnpm", "verify")

# Hard time ceiling for one Phase-1 self-evolution run.  Mirrors
# time_budget.DEFAULT_RUN_CEILING_SECS; kept as a literal here because the
# theatre checkout has to be on sys.path before garage modules are importable.
# The CLI default is resolved per phase (Phase 1 here, the DRS on
# time_budget.DRS_RUN_CEILING_SECS) — an explicit --run-ceiling-secs always
# wins over both.
_DEFAULT_RUN_CEILING_SECS = 1500

# ---------------------------------------------------------- gate preflight

def _wave_host_no_browser() -> None:
    """Every platform: default this orchestrator to a browserless host policy.

    On macOS every Chromium launch writes a per-launch GUID-named keychain
    item and pops a keychain prompt on the user's screen (see
    guest_env._disable_in_guest_browser for the full measurement record) —
    no flag, shim, or pre-authorization suppresses it.  The guest already
    exports a no-browser sentinel; the host-side merge gate
    (wave_merge.run_gate inherits this process's environment) must not
    undo that policy by resolving the real Edge out of its candidate list.
    setdefault keeps an operator's explicit FEUILLE_BROWSER (a deliberate
    browserful run) authoritative.

    2026-10-19 (user decision): this now covers Windows too.  The Windows wave
    host's Edge fails 4/4 rendering specs deterministically under vitest
    (browser() resolves Edge, headless writes no screenshot, bare
    Edge --screenshot succeeds), so every candidate would be judged FAIL at the
    merge gate.  Browserless turns those into honest SKIPs.  Cost stated
    plainly: the render path is NOT exercised during a wave (SKIP is not PASS).
    """
    os.environ.setdefault(
        "FEUILLE_BROWSER",
        str(_HERE / ".no-browser-on-this-host"))


_NODE_MIN_MAJOR = 24
_PNPM_MIN_MAJOR = 11
_PNPM_NAMES = frozenset({"pnpm", "pnpm.exe", "pnpm.cmd", "pnpm.bat"})
# Directory holding the winget-installed standalone pnpm.exe.  It is NOT on
# the default Windows PATH in front of the npm shim directory
# (AppData\Roaming\npm wins), so a bare `pnpm` keeps resolving to the 10.x
# shim.  The guest inherits THIS process's PATH (guest_env assembles it), so
# the host fix and the guest fix are the same fix.
_PNPM_STANDALONE_DIRS = (
    Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet"
    / "Packages",
)


def _prepend_standalone_pnpm() -> str | None:
    """Put a standalone pnpm.exe directory in front of the process PATH.

    Returns the directory that was prepended, or None when nothing suitable
    was found.  Idempotent: a directory already at the front is left alone.

    Measured 2026-10-19: with the npm shim first, both the host gate and the
    GUEST toolchain probe resolved pnpm 10.32.0 and failed closed
    ("guest pnpm too old for the workspace gate: '10.32.0' (need >= 11)") —
    three seconds in, before a single token was spent.  The same directory
    holds pnpm 12.11.2.
    """
    for packages in _PNPM_STANDALONE_DIRS:
        if not packages.is_dir():
            continue
        for candidate in sorted(packages.glob("pnpm.pnpm_*")):
            binary = candidate / "pnpm.exe"
            if not binary.is_file():
                continue
            directory = str(candidate)
            current = os.environ.get("PATH", "")
            head = current.split(os.pathsep)[0] if current else ""
            if os.path.normcase(head) == os.path.normcase(directory):
                return None
            os.environ["PATH"] = os.pathsep.join(
                [directory] + ([current] if current else []))
            log.info("prepended standalone pnpm to PATH: %s", directory)
            return directory
    return None


def _command_version(argv0: str) -> str | None:
    """First line of ``<argv0> --version``, or None when it cannot run."""
    try:
        proc = subprocess.run(
            [argv0, "--version"], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=120, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if proc.returncode != 0:
        return None
    text = proc.stdout.decode("utf-8", "replace").strip()
    return text.splitlines()[0] if text else None


def _version_major(version: str | None) -> int | None:
    match = re.search(r"(\d+)", version or "")
    return int(match.group(1)) if match else None


def gate_preflight(usine_dir: Path, gate_argv: tuple,
                   *, allow_install: bool = False) -> dict:
    """Fail-closed gate-runnability preflight; {ok: bool, ...}.

    A red gate at merge time is a data-level ``gate_rejected`` — the whole
    candidate is lost with no retry.  A gate that cannot run AT ALL (missing
    toolchain, .cmd shim, uninstalled tree) must therefore be caught here,
    BEFORE a single token is spent, not after a wave's worth of Actor work.

    Pnpm-shaped gates additionally require Node >= 24 and pnpm >= 11 on
    PATH (the documented wave-host prerequisites), a package.json at the
    usine root, and an installed tree; ``allow_install`` opts into running
    ``pnpm install --frozen-lockfile --prefer-offline`` right here."""
    argv0 = str(gate_argv[0])
    errors: list[str] = []
    actions: list[str] = []
    info: dict = {"gate_argv": [str(a) for a in gate_argv]}
    resolved = shutil.which(argv0)
    if resolved is None:
        errors.append(f"gate command {argv0!r} was not found on PATH")
    elif os.path.basename(resolved).lower().endswith((".cmd", ".bat")):
        # Windows trap: the merge runs the gate with shell=False; CreateProcess
        # executes .exe, not .cmd shims — an npm-installed pnpm.cmd would die
        # as an unrunnable gate AFTER the wave, i.e. silent candidate loss.
        errors.append(
            f"{argv0!r} resolves to {resolved!r}: a .cmd/.bat shim cannot "
            "be spawned by the merge's shell-less subprocess — install the "
            "standalone pnpm (pnpm.exe) from the official installer")
    else:
        info["gate_resolved"] = resolved
        version = _command_version(argv0)
        info["gate_version"] = version
        if version is None:
            errors.append(
                f"gate command {argv0!r} was found but --version failed to run")
    if os.path.basename(argv0).lower() in _PNPM_NAMES:
        node_version = _command_version("node") if shutil.which("node") \
            else None
        info["node_version"] = node_version
        if node_version is None:
            errors.append(
                "node was not found on PATH: the pnpm gate needs "
                f"Node >= {_NODE_MIN_MAJOR} (wave-host prerequisite)")
        elif (_version_major(node_version) or 0) < _NODE_MIN_MAJOR:
            errors.append(
                f"node {node_version} is too old: the pnpm gate needs "
                f"Node >= {_NODE_MIN_MAJOR}")
        pnpm_version = info.get("gate_version")
        if pnpm_version is not None \
                and (_version_major(pnpm_version) or 0) < _PNPM_MIN_MAJOR:
            errors.append(
                f"pnpm {pnpm_version} is too old: pnpm >= {_PNPM_MIN_MAJOR} "
                "is required (workspace lockfile format)")
        if not (usine_dir / "package.json").is_file():
            errors.append(
                f"{usine_dir} has no package.json: --usine-dir must name the "
                "pnpm workspace root of the TS monorepo")
        else:
            installed = (usine_dir / "node_modules").is_dir()
            if not installed and allow_install:
                log.info("gate preflight: tree not installed; running "
                         "pnpm install --frozen-lockfile --prefer-offline")
                try:
                    proc = subprocess.run(
                        [argv0, "install", "--frozen-lockfile",
                         "--prefer-offline"], cwd=str(usine_dir),
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        timeout=1800, check=False)
                except (OSError, subprocess.TimeoutExpired) as exc:
                    errors.append(f"pnpm install failed to start: {exc}")
                    proc = None
                if proc is not None:
                    tail = proc.stdout.decode("utf-8", "replace")[-800:]
                    info["install_exit"] = proc.returncode
                    if proc.returncode != 0:
                        errors.append(
                            f"pnpm install exited {proc.returncode}; tail: "
                            f"{tail!r}")
                    else:
                        actions.append(
                            "ran pnpm install --frozen-lockfile "
                            "--prefer-offline")
                        installed = (usine_dir / "node_modules").is_dir()
                        if not installed:
                            errors.append(
                                "pnpm install exited 0 but node_modules is "
                                "still absent")
            if not installed and not allow_install:
                errors.append(
                    "the usine tree is not installed (no node_modules): run "
                    "`pnpm install --frozen-lockfile --prefer-offline` from "
                    f"{usine_dir} — or pass --gate-install to let the "
                    "preflight install it")
    return {"ok": not errors, "errors": errors, "actions": actions, **info}



EXECUTE_ACK = "RUN-USINE-PHASE1-WAVES"
# DRS (paper RSIAgent 2.2, Phase 2) gets its OWN ack token, never a flag on
# the Phase-1 one: "真波次喊跑才跑" is a per-wave consent discipline, and a
# deep-recursion wave must never be started by a stale Phase-1 command line.
EXECUTE_ACK_DRS = "RUN-USINE-PHASE2-DRS"
_SAFE_NAME = re.compile(r"[A-Za-z0-9_.-]+\Z")
# The approved usine lineup.  Anything outside this set fails closed before a
# single token is spent (user constraint: the 2026-10-19 reseating moved every
# usine seat onto the fuyao pair; the MiniMax pair left the lineup).
ALLOWED_MODEL_SLUGS = frozenset({
    "fuyao-work",
    "fuyao-coding",
})

ROLE_FILES = {
    "actor": "actor-usine.yaml",
    "verifier": "verifier-usine.yaml",
    "verifier_control": "target-usine.yaml",
    "curriculum": "curriculum-usine.yaml",
    # The DRS (Phase 2) gets its OWN curriculum seat.  Phase 1 authors a
    # breadth wave; the DRS hands the Actor one deep drill, and the DRS drill
    # needs a different brief — an open-set brief ("every message in this
    # category", a per-message report) drove the Actor through seventeen
    # reconnaissance rounds and the run ended with an unchanged memory tree
    # (bfs16g, 2026-10-20).  A slice can absorb variance; it cannot absorb an
    # unbounded task, so the bound belongs in the brief.
    "curriculum_drs": "curriculum-drs.yaml",
    "memory_actor": "actor-usine.yaml",
}

signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))


# ---------------------------------------------------------------- io helpers

def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_atomic(path: Path, value: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8")
    os.replace(temporary, path)


def _append_event(path: Path, event_type: str, *, status: str,
                  state: dict, payload: dict) -> None:
    record = {
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "event_type": event_type,
        "status": status,
        "state": state,
        "payload": payload,
    }
    with Path(path).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True)
                     + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _inspect_memory_seed(source: Path) -> dict:
    """Describe a memory tree that will seed a run (never its contents).

    A seed is a DIRECTORY of memory records (``*.md``).  It is what a
    previous wave — or a previous DRS — learned, and installing it is how
    the next run starts on top of that knowledge instead of rediscovering
    it.  The engine reads the run's ``memory/`` directory as the starting
    tree (the Curriculum seat reads it, the Actor is handed it), so
    seeding is a directory copy: no engine change is involved.
    """
    source = Path(source)
    files = sorted(path for path in source.rglob("*") if path.is_file())
    return {
        "path": str(source),
        "files": len(files),
        "bytes": sum(path.stat().st_size for path in files),
        "names": [str(path.relative_to(source)) for path in files][:64],
    }


def _merge_drs_into_usine(run_root: Path, merge_config) -> dict:
    """Merge a DRS episode's candidate into the usine tree.

    The DRS's serial core closes its episode with ``PROJECT_CLOSED``, not
    ``PHASE1_WAVE_COMPLETED``, so the wave-merge event sink never fires:
    the candidate — verifier PASS, offline gate green — stays in the run
    root and the repository never changes.  This runs the SAME machinery a
    breadth wave goes through (delta, drift check, the offline gate against
    the REAL tree, commit, tag), so a DRS improvement lands under the same
    rules as everything else, and it is re-gated on the way in rather than
    trusted from the guest.

    The outcome is REPORTED, never assumed.  A merge failure is recorded
    in the payload (and the process exits 4) instead of turning into a
    silent no-op: "the DRS produced an improvement" and "the improvement is
    in the repository" are two different claims.
    """
    import wave_merge
    try:
        report = wave_merge.merge_drs_run(str(run_root), merge_config)
    except wave_merge.UsineMergeError as exc:
        log.error("DRS merge failed: %s", exc)
        return {"ok": False, "error": str(exc)}
    candidates = []
    for entry in report.get("candidates", []):
        gate = entry.get("gate") or {}
        candidates.append({
            "project_index": entry.get("project_index"),
            "decision": entry.get("decision"),
            "reason": entry.get("reason"),
            "commit": entry.get("commit"),
            "delta": entry.get("delta"),
            "gate_exit_code": gate.get("exit_code"),
        })
    return {
        "ok": True,
        "commits": report.get("commits", []),
        "tag": report.get("tag"),
        "tag_created": report.get("tag_created", False),
        "base_commit": report.get("base_commit"),
        "gate_seconds_total": report.get("gate_seconds_total"),
        "drs_episodes": report.get("drs_episodes", []),
        "candidates": candidates,
    }


def _install_seed_memory(source: Path, destination: Path) -> int:
    """Copy a canonical memory tree into a fresh lineage root.

    DRS starts from the Phase-1 memory tree verbatim — same bytes, same
    relative layout.  A COPY (never a move or a link) keeps Phase 1's
    manifest and tree hash authoritative: the DRS delta is measured against
    it, and Phase 1 must stay re-readable after a deep run.
    """
    source, destination = Path(source), Path(destination)
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    installed = 0
    for candidate in sorted(source.rglob("*")):
        relative = candidate.relative_to(source)
        if candidate.is_symlink():
            raise RuntimeError(f"memory seed contains a symlink: {relative}")
        target = destination / relative
        if candidate.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif candidate.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(candidate, target)
            installed += 1
    return installed


def _default_checkpoints(budget: int) -> str:
    """Checkpoint list scaled to the project budget.

    The historical default ``0,2,4,8`` assumes the paper's budget of 8
    projects.  Asking for a SMALLER budget (a cheap first wave is exactly
    what a new operator tries) must not crash argument parsing with
    "checkpoints must lie between zero and the project budget" — that error
    names the wrong problem, and it fires before the run even starts.
    """
    if budget <= 0:
        return "0"
    return ",".join(str(index) for index in (0, 2, 4, 8) if index <= budget)


def _parse_checkpoints(value: str, budget: int) -> tuple[int, ...]:
    try:
        checkpoints = tuple(sorted(set(
            int(item.strip()) for item in value.split(",") if item.strip())))
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "checkpoints must be comma-separated integers") from exc
    if any(index < 0 or index > budget for index in checkpoints):
        raise argparse.ArgumentTypeError(
            "checkpoints must lie between zero and the project budget")
    return checkpoints


def _safe_phase_root(runs_root: str, name: str, phase: str = "1") -> Path:
    if not _SAFE_NAME.fullmatch(name) or name in {".", ".."}:
        raise ValueError("--run-name must be one safe basename")
    if phase not in {"1", "2"}:
        raise ValueError("phase must be 1 or 2")
    base = Path(runs_root).expanduser().resolve(strict=False)
    # Phase 2 is a SIBLING of Phase 1 under the same lineage: it deepens the
    # memory that run produced, and it must never write into it (the Phase-1
    # manifest/tree-hash record is the baseline a DRS delta is measured against).
    root = (base / name / f"phase{phase}").resolve(strict=False)
    if root.parents[1] != base:
        raise ValueError(f"Phase-{phase} result root escapes the runs root")
    return root


def _phase1_memory_dir(runs_root: str, name: str) -> Path:
    """The canonical Phase-1 memory tree a DRS run must deepen.

    DRS is only meaningful over memory that already exists (paper 2.2: the
    deep wave drills gaps the breadth wave exposed).  Starting from an empty
    Phase-1 tree would make Phase 2 a second breadth wave wearing a DRS label.
    """
    base = Path(runs_root).expanduser().resolve(strict=False)
    memory = (base / name / "phase1" / "memory").resolve(strict=False)
    if memory.parents[2] != base:
        raise ValueError("Phase-1 memory path escapes the runs root")
    return memory


def _resolve_input_file(value: str, *, repo_root: Path) -> Path:
    raw = Path(value).expanduser()
    candidate = raw if raw.is_absolute() else repo_root / raw
    if candidate.is_symlink():
        raise RuntimeError(f"input path may not be a symlink: {candidate}")
    path = candidate.resolve(strict=True)
    if not path.is_file():
        raise RuntimeError(f"input path is not one file: {path}")
    return path


def _install_paths() -> Path:
    theatre = DEFAULT_THEATRE.resolve(strict=True)
    if not (theatre / "core" / "actor.py").is_file():
        raise RuntimeError(f"théâtre checkout is missing core/: {theatre}")
    for path in (str(theatre), str(_HERE)):
        if path not in sys.path:
            sys.path.insert(0, path)
    return theatre


# ------------------------------------------------- actor system-prompt patch

# Exact stock substrings (core/actor.py _SYSTEM_TEMPLATE + the two look
# bullets, backslash continuations already collapsed).  Shared seams occur
# once in BOTH stock variants; each look bullet is exclusive to its variant.
_TASK_LINE_OLD = ("You solve ONE task on a real Ubuntu machine by WRITING "
                  "PROGRAMS.")
# Substrate-true per host: the Windows wave host drives git-bash, POSIX
# dev hosts (macOS) drive plain bash.  The replacement text is
# platform-branched so the patched prompt never lies about the machine.
_TASK_LINE_NEW = (
    ("You solve ONE task on a real Windows machine driven "
     "through git-bash by WRITING PROGRAMS.")
    if os.name == "nt" else
    ("You solve ONE task on a real POSIX machine (macOS) driven "
     "through bash by WRITING PROGRAMS."))
_MACHINE_FACTS_OLD = ("MACHINE FACTS: Ubuntu with python3. You may install "
                      "tools you need (pip3 / apt-get).")
# Honest replacement: the théâtre venv has NO pip (probe-verified on both
# hosts), and installing packages is not part of this environment — brew
# exists on the POSIX host PATH but must not be used.
_MACHINE_FACTS_NEW = (
    ("MACHINE FACTS: Windows host driven through git-bash "
     "with python3. Installing packages is NOT available "
     "here (no pip3, no apt-get); work with the tools "
     "already on the machine. There is no systemd and no "
     "GUI desktop.")
    if os.name == "nt" else
    ("MACHINE FACTS: macOS host driven through bash "
     "with python3 (no pip). Installing packages is NOT available "
     "here; work with the tools already on the machine — brew exists "
     "but must not be used to install anything. There is no systemd "
     "and no GUI desktop."))
_NATIVE_LOOK_OLD = (
    'You may look directly at a DOCUMENT file (it is rendered to an image '
    'for you) and at the LIVE SCREEN with path "screen:" (the running '
    'desktop/GUI state).')
_BLIND_LOOK_OLD = (
    'You may look directly at a DOCUMENT file (it is rendered to an image '
    'for you \u2014 no need to convert it first) and at the LIVE SCREEN '
    'with path "screen:" (the running desktop/GUI state, when the result '
    'you must judge is on screen rather than in a file).')
# Substrate-true for both variants: image-file Looks still work (pixels are
# read host-side), but there is no document renderer and no live screen.
_LOOK_NEW = (
    'There is no rendered-document channel and no live screen on this '
    'machine: "screen:" is unavailable, and documents are not rendered to '
    'images. Read every file (documents included) by WRITING PROGRAMS that '
    'open and read it.')

_USINE_PROMPT_REPLACEMENTS = (
    (_TASK_LINE_OLD, _TASK_LINE_NEW),
    (_MACHINE_FACTS_OLD, _MACHINE_FACTS_NEW),
    (_NATIVE_LOOK_OLD, _LOOK_NEW),
    (_BLIND_LOOK_OLD, _LOOK_NEW),
)

if os.name == "nt":
    _USINE_TRANSPORT_NOTE = """
USINE TRANSPORT FACTS (Windows git-bash guest):
- Your programs are delivered through a base64 envelope and executed with
  "python3 -u" (python) or "bash" (bash); nothing rewrites paths inside your
  program text.
- PYTHON programs: the canonical paths work as-is - /home/user (your home),
  /home/user/evolution_project (the project root), /tmp, /dev/shm.
- BASH programs: literal /home/user and /dev/shm resolve to the bash
  installation's own directories, NOT to your guest tree - use $HOME or ~
  (your home directory) instead. For scratch space in bash use $HOME too
  (e.g. "$HOME/scratch"); a literal /tmp in bash resolves through a mount
  shared by other processes and is NOT reliable in your guest.
"""
else:
    # POSIX twin: the Windows note's PYTHON paragraph is FALSE here - a
    # literal canonical path inside program text resolves against the REAL
    # host root (no per-drive resolution), so both languages must use
    # $HOME/~.  The gate/pnpm/node_modules paragraphs are shared verbatim.
    _USINE_TRANSPORT_NOTE = """
USINE TRANSPORT FACTS (POSIX bash guest on a macOS host):
- Your programs are delivered through a base64 envelope and executed with
  "python3 -u" (python) or "bash" (bash); nothing rewrites paths inside your
  program text.
- Program paths: a LITERAL /home/user, /tmp or /dev/shm inside your program
  text resolves against the REAL host root, NOT against your guest tree -
  in Bash AND in Python alike. Reach your files through $HOME or ~ (your
  home directory; Python: os.path.expanduser), so $HOME/evolution_project
  is the project root and "$HOME/scratch" is scratch space; /dev/shm exists
  in your guest.
"""

_USINE_TRANSPORT_NOTE += """
- The offline verification gate is "pnpm verify" (a TypeScript pnpm
  monorepo: typecheck plus every vitest suite), run from the project root
  after a one-time "pnpm install":
    bash:   cd "$HOME/evolution_project" && pnpm install && pnpm verify
  Node 24+ and pnpm 11 must be on PATH. The first install fills the pnpm
  store (needs network once); later runs reuse it. Never edit anything
  under node_modules - it is installed material, not work.
  EACH of your programs is limited to 600 seconds (the in-guest kill fires
  30 seconds earlier and the partial output survives): run the one-time
  "pnpm install" and the later "pnpm verify" as SEPARATE programs, never
  as one chained command - an install-then-verify chain risks the kill in
  the middle of the suite.
  node_modules and dist are NOT part of your captured work: the capture
  prunes them by name at any depth, and the merge side prunes them too.
  They are fully regenerable (pnpm install / build) and are rebuilt
  automatically after a green merge - spend your turns on tracked source,
  never on them.
  "pnpm vitest run packages/<pkg>" runs one package's suite. Live platform
  publishing and platform login never run in this environment: those
  programs are refused before execution, so develop and verify offline only."""


def _install_actor_prompt_patch() -> None:
    """Wrap core.actor/core.loop build_system with substrate-true text.

    Fail-closed at install time: every seam substring is pinned against both
    stock variants (native build_system(None) and a blind probe cfg), and the
    patched products must carry each replacement exactly once.  Upstream
    template drift therefore raises instead of silently no-op'ing.
    """
    import core.actor as actor_mod
    import core.loop as loop_mod

    stock = actor_mod.build_system
    blind_probe = SimpleNamespace(
        vision_model="usine-seam-probe", system_extra="", action_discipline=False)
    native = stock(None)
    blind = stock(blind_probe)
    for old, _new in _USINE_PROMPT_REPLACEMENTS[:2]:
        if native.count(old) != 1 or blind.count(old) != 1:
            raise RuntimeError(
                "usine actor-prompt seam drifted (shared): " + old[:48])
    if (native.count(_NATIVE_LOOK_OLD) != 1
            or _NATIVE_LOOK_OLD in blind):
        raise RuntimeError("usine actor-prompt seam drifted (native look)")
    if (blind.count(_BLIND_LOOK_OLD) != 1
            or _BLIND_LOOK_OLD in native):
        raise RuntimeError("usine actor-prompt seam drifted (blind look)")

    def usine_system(cfg=None, *, ask_enabled: bool = False) -> str:
        text = stock(cfg, ask_enabled=ask_enabled)
        for old, new in _USINE_PROMPT_REPLACEMENTS:
            text = text.replace(old, new)
        return text + _USINE_TRANSPORT_NOTE

    patched_native = usine_system(None)
    patched_blind = usine_system(blind_probe)
    if (patched_native.count(_TASK_LINE_NEW) != 1
            or patched_native.count(_MACHINE_FACTS_NEW) != 1
            or patched_native.count(_LOOK_NEW) != 1
            or patched_native.count(_TASK_LINE_OLD)
            or patched_native.count(_MACHINE_FACTS_OLD)
            or patched_native.count(_NATIVE_LOOK_OLD)):
        raise RuntimeError("usine native actor patch did not apply cleanly")
    if (patched_blind.count(_LOOK_NEW) != 1
            or patched_blind.count(_BLIND_LOOK_OLD)
            or patched_blind.count(_TASK_LINE_OLD)
            or patched_blind.count(_MACHINE_FACTS_OLD)):
        raise RuntimeError("usine blind actor patch did not apply cleanly")

    actor_mod.build_system = usine_system
    loop_mod.build_system = usine_system
    log.info("actor system prompt patched for the usine substrate "
             "(core.actor + core.loop)")


# ---------------------------------------------------------------- role configs

def _load_roles():
    """Load the five usine role configs and validate the decided lineup."""
    from config.runtime_paths import normalize_verifier_config_paths, resolve_path
    from config.settings import load

    paths, configs = {}, {}
    for role, name in ROLE_FILES.items():
        path = resolve_path(
            Path("config") / "roles-usine" / name, repo_root=_HERE)
        if not path.is_file():
            raise RuntimeError(f"usine role config is missing: {path}")
        cfg = load(str(path))
        normalize_verifier_config_paths(cfg, _HERE)
        paths[role] = path
        configs[role] = cfg

    # Stock Phase-1 practice invariants for the four agent seats.
    for role in ("actor", "verifier", "curriculum", "curriculum_drs",
                 "memory_actor"):
        cfg = configs[role]
        if (not cfg.agent_decided_stop or not cfg.practice_mode
                or cfg.independent_verify or cfg.max_resumes != 0):
            raise RuntimeError(
                f"usine Phase-1 {role} must use Agent-owned practice mode")
    if configs["memory_actor"].model != configs["actor"].model:
        raise RuntimeError(
            "memory writing must continue with the same Actor Agent model")

    control = configs["verifier_control"]
    for attribute in ("agentic_verifier_config",
                      "escalation_agentic_verifier_config"):
        value = getattr(control, attribute, "")
        if not value or not Path(value).is_file():
            raise RuntimeError(
                f"control.{attribute} does not resolve to a file: {value!r}")
    escalation_cfg = load(str(control.escalation_agentic_verifier_config))
    if (not escalation_cfg.practice_mode or escalation_cfg.independent_verify
            or escalation_cfg.max_resumes != 0):
        raise RuntimeError(
            "escalated verifier seat must use Agent-owned practice mode")
    return configs, paths, escalation_cfg


def _check_lineup(configs: dict, escalation_cfg) -> dict:
    """Fail closed on any drift from the decided usine model lineup."""
    actor = configs["actor"]
    curriculum = configs["curriculum"]
    verifier = configs["verifier"]
    control = configs["verifier_control"]

    # 2026-10-18 lineup switch (user decision): M3 actor thrashed on wave-1r
    # (220+ iters, one 570s timeout with 25 MB stdout); the Actor and its
    # memory twin move to fuyao-coding.  2026-10-19 reseating (user decision):
    # the control seat moves to fuyao-coding as well and the MiniMax pair
    # leaves the lineup entirely; the control seat remains the
    # escalated-verifier fallback and the vision / cross-model invariants
    # below are pinned to the fuyao pair.
    if actor.model != "fuyao-coding":
        raise RuntimeError("usine Actor Agent must be fuyao-coding")
    if actor.vision_model != "":
        raise RuntimeError("usine Actor Agent must use native vision")
    if curriculum.model != "fuyao-work":
        raise RuntimeError("usine Curriculum Agent must be fuyao-work")
    if curriculum.vision_model != "fuyao-coding":
        raise RuntimeError("usine Curriculum eyes must be fuyao-coding")
    if verifier.model != "fuyao-work":
        raise RuntimeError(
            "usine Agentic Verifier must be fuyao-work")
    if verifier.vision_model != "":
        raise RuntimeError("usine Agentic Verifier must use native vision")
    if control.model != "fuyao-coding":
        raise RuntimeError("usine control Actor seat must be fuyao-coding "
                           "(the escalated verifier falls back to it)")
    if control.verifier_model != "fuyao-work":
        raise RuntimeError("usine control verifier_model drifted")
    if control.escalation_model != "fuyao-work":
        raise RuntimeError("usine control escalation_model drifted")
    if control.vision_model != control.escalation_model:
        raise RuntimeError(
            "control.vision_model must equal escalation_model so the "
            "escalated Actor keeps native vision")
    if not control.escalation_verifier_cross_model:
        raise RuntimeError("control.escalation_verifier_cross_model must be "
                           "true (xverify: no escalated self-review)")
    if not control.independent_verify or control.verifier_stage_lifecycle:
        raise RuntimeError("usine candidate-only control profile drifted")
    if control.verifier_execution_mode != "rollback_mirror":
        raise RuntimeError("usine control must use the rollback_mirror "
                           "execution boundary")
    if not control.verifier_hide_actor_memory:
        raise RuntimeError("usine control must hide Actor memory")

    # Mirror core.loop.escalation_cfg math exactly and pin the result.
    esc_verifier = control.verifier_model or control.model
    if (control.escalation_verifier_cross_model
            and esc_verifier == control.escalation_model):
        esc_verifier = control.model
    esc_vision = ("" if (control.vision_model
                         and control.escalation_model == control.vision_model)
                  else control.vision_model or control.model)
    if esc_verifier != "fuyao-coding" or esc_vision != "":
        raise RuntimeError(
            f"escalated seats drifted: verifier={esc_verifier!r} "
            f"vision={esc_vision!r}")
    if escalation_cfg.model != esc_verifier:
        raise RuntimeError(
            "escalation verifier config must seat the computed cross-model "
            f"verifier ({esc_verifier})")
    if escalation_cfg.vision_model != "":
        raise RuntimeError("escalated verifier seat must use native vision")

    used = {
        value for value in (
            configs["actor"].model, configs["actor"].vision_model,
            configs["memory_actor"].model, configs["memory_actor"].vision_model,
            curriculum.model, curriculum.vision_model,
            verifier.model, verifier.vision_model,
            control.model, control.verifier_model,
            control.escalation_model, control.vision_model,
            escalation_cfg.model, escalation_cfg.vision_model,
            esc_verifier, esc_vision)
        if value}
    unknown = sorted(value for value in used
                     if value not in ALLOWED_MODEL_SLUGS)
    if unknown:
        raise RuntimeError(
            f"model outside the approved usine lineup: {unknown}")
    return {"esc_actor": control.escalation_model,
            "esc_verifier": esc_verifier,
            "esc_vision": esc_vision,
            "used_models": sorted(used)}


def _check_drs_wiring(configs: dict) -> None:
    """Fail closed on a broken DRS verifier wiring BEFORE any token is spent.

    The DRS path runs the stock SERIAL core (explore/practice_loop.py), which
    takes the Verifier CONTROL profile in ``agentic_verifier_cfg`` — that
    profile names the Verifier AGENT config in ``agentic_verifier_config`` and
    carries the private-path quarantine the inspection needs.  Phase 1 passes
    that control profile; the DRS path used to pass the Verifier AGENT
    profile, which has no ``agentic_verifier_config`` key at all, so the core
    refused the inspection with "Phase-1 Agentic Verifier control config is
    missing" — AFTER the Actor had already spent its whole budget (measured
    2026-10-20, bfs16f: 1158s spent and a candidate produced, then refused).

    A wiring gap must cost a preflight, not a twenty-minute run.  Every
    condition here is checkable without a token.
    """
    control = configs.get("verifier_control")
    if control is None:
        raise RuntimeError(
            "--phase 2 needs the verifier CONTROL profile "
            "(verifier_control), which is missing from the loaded roles")
    named = str(getattr(control, "agentic_verifier_config", "") or "")
    if not named:
        raise RuntimeError(
            "--phase 2 needs the verifier CONTROL profile to name the "
            "Verifier Agent config in agentic_verifier_config; the loaded "
            "control profile does not.  The serial core reads it from there "
            "and refuses the inspection without it.")
    if not Path(named).is_file():
        raise RuntimeError(
            f"--phase 2 verifier control names a missing Verifier Agent "
            f"config: {named}")
    if not str(getattr(control, "verifier_model", "") or ""):
        raise RuntimeError(
            "--phase 2 verifier control has no verifier_model; the serial "
            "core would have no Verifier Agent to drive.")
    # The DRS curriculum seat must actually be the one in the curriculum
    # slot.  Running the DRS with Phase-1's breadth brief is exactly the
    # unbounded-task failure this seat exists to prevent, and it costs a
    # thirty-minute run to discover — so it is a preflight failure.
    if configs.get("curriculum") is not configs.get("curriculum_drs"):
        raise RuntimeError(
            "--phase 2 must run the DRS curriculum seat "
            "(curriculum-drs.yaml) in the curriculum slot; the Phase-1 "
            "breadth brief has no drill bound and the Actor cannot finish "
            "an open-set task inside its time budget.")


def _select_phase_seats(configs: dict, role_paths: dict,
                        phase: str) -> tuple[dict, dict]:
    """Put the seat this phase actually runs into the ``curriculum`` slot.

    Phase 1 authors a breadth wave (curriculum-usine.yaml).  Phase 2 is the
    DRS: the curriculum reviews the memory Phase 1 produced and hands the
    Actor ONE deep drill, which needs a different brief — a drill with a
    closed scope (one source file, one test file, at most two deliverables,
    a table-shaped report, an existing memory record to deepen).  The
    unbounded brief Phase 1 can afford is the one that killed five DRS runs:
    the Actor spent its whole time budget searching for the open set instead
    of changing anything, and the run ended with an unchanged memory tree
    (bfs16g, 2026-10-20).

    The swap is a seat SELECTION, not a behaviour switch: both configs are
    loaded, both are lineup-checked, and the DRS config is only promoted when
    the phase is 2.  Nothing else in the run changes.
    """
    if phase != "2":
        return configs, role_paths
    drs_cfg = configs.get("curriculum_drs")
    if drs_cfg is None:
        raise RuntimeError(
            "--phase 2 needs the DRS curriculum seat "
            "(config/roles-usine/curriculum-drs.yaml), which is missing")
    configs = dict(configs)
    configs["curriculum"] = drs_cfg
    drs_path = role_paths.get("curriculum_drs")
    if drs_path is not None:
        role_paths = dict(role_paths)
        role_paths["curriculum"] = drs_path
    return configs, role_paths


# ------------------------------------------------- spread gate / latency gate

def _apply_spread_constraint(configs: dict, *, phase: str, state: dict,
                             config) -> dict:
    """把铺开约束追加进**出题席**的 system_extra（装配期，一次性）。

    为什么必须落在 system_extra 而不是别的提示词里：出题席的指令只有这一份
    （``config/roles-usine/curriculum-usine.yaml`` 的 ``system_extra``），引擎把它
    拼在 ``core/actor.py`` 的系统提示后面。约束不进这里，就只是一句没人读的注释。

    只动 Phase-1 的出题席：Phase 2（DRS）有自己的出题席
    （``curriculum-drs.yaml``，由 ``_select_phase_seats`` 换席），它的工作是复盘
    并交一个**有上界的 drill**，不是选题铺开——把广度波次的口味塞进深度波次，
    只会稀释 DRS 那套「brief 必须有上界」的纪律。

    判相位用**换席后的身份**（curriculum 槽里装的是不是 DRS 席），而不是配置
    文件名：换席是 ``_select_phase_seats`` 干的活，身份判定不会和它脱节。
    """
    import spread

    curriculum = configs.get("curriculum")
    if curriculum is None:
        return {"applied": False, "reason": "no curriculum seat in this run"}
    if curriculum is configs.get("curriculum_drs") or phase != "1":
        return {
            "applied": False,
            "reason": "phase 2 runs the DRS curriculum seat; the spread gate "
                      "is a breadth-wave mechanism and the DRS brief has its "
                      "own bound",
        }
    result = spread.apply_to_seat(curriculum, state, config)
    result["reason"] = result.get("reason", "")
    return result


def _latency_blocks(latency_report: dict) -> bool:
    """时延风险是否挡住了这次开跑。

    高风险且**没有**被显式放行 → 挡住（fail-closed：切片吸收不了波动，运气差就
    整波烧光）。被 ``--allow-high-latency`` 放行的不挡，但风险会被写进 manifest
    ——放行不等于没有发生过。
    """
    return (latency_report.get("risk") == "high"
            and not latency_report.get("allowed"))


def _latency_manifest_entry(latency_report: dict) -> dict:
    """manifest 里的时延风险标记。

    被 ``--allow-high-latency`` 放行的高时延风险**必须**在 manifest 里看得见：
    一个被放行却没被记录的风险，和一个根本没检查过的风险，读起来一模一样。
    """
    return {
        "latency_preflight": {
            "risk": latency_report.get("risk", "none"),
            "allowed": bool(latency_report.get("allowed")),
            "latency_history": latency_report.get("latency_history", "none"),
            "reason": latency_report.get("reason", ""),
            "seats": latency_report.get("seats", {}),
        }
    }


def _resume_manifest_key(manifest: dict) -> dict:
    """resume 逐字比对的 manifest 键。

    ``latency_preflight`` 是对 runs 根目录的**观测**，不是协议/配置决定：操作员
    可能在原跑与 resume 之间又跑了别的血脉，评估值因此会变；而它每次入口都会
    重算（execute 路径同样会判，高风险照样被拒），所以把它排除在逐字比对之外
    不会放过任何风险。其余一切（席位、切片、corpus 哈希、合并设置）必须逐字相同。
    """
    trimmed = dict(manifest)
    trimmed.pop("latency_preflight", None)
    return trimmed


# ---------------------------------------------------------------- credentials

def _context_budget_check(configs: dict) -> dict:
    """Static self-consistency check of every seat's context budget.

    Wave1r-lineup-switch died at ~40 minutes with ``HTTP 400 context window
    exceeds limit (2013)`` — the provider's real window was far below what
    the seat assumed.  That failure was invisible until the LLM call was
    already made, i.e. after seeding a VM and burning a wave's time budget.

    This check is deliberately STATIC (no request, no token): it compares
    each seat's declared high-water mark, its per-reply output cap, and the
    history retention policy, and reports any combination that cannot hold a
    conversation.  The authoritative limit lives at the provider, so this
    cannot prove a window is big enough — it can only catch a seat whose own
    declarations contradict each other, which is the failure mode that is
    cheap to fix before a wave instead of during one.
    """
    findings: list[str] = []
    seats: dict[str, dict] = {}
    for name, cfg in sorted(configs.items()):
        high = int(getattr(cfg, "ctx_high_water", 0) or 0)
        low = int(getattr(cfg, "ctx_low_water", 0) or 0)
        out = int(getattr(cfg, "max_tokens", 0) or 0)
        keep = int(getattr(cfg, "keep_chars", 0) or 0)
        pairs = int(getattr(cfg, "history_keep_pairs", 0) or 0)
        seats[name] = {
            "ctx_high_water": high, "ctx_low_water": low,
            "max_tokens": out, "keep_chars": keep,
            "history_keep_pairs": pairs,
        }
        if high and out >= high:
            findings.append(
                f"{name}: max_tokens ({out}) leaves no room under "
                f"ctx_high_water ({high})")
        if high and low and low >= high:
            findings.append(
                f"{name}: ctx_low_water ({low}) is not below ctx_high_water "
                f"({high}) — folding would never trigger")
        if high and not (low or pairs or keep):
            findings.append(
                f"{name}: ctx_high_water {high} is declared but no retention "
                f"policy is configured (ctx_low_water, history_keep_pairs "
                f"and keep_chars are all empty) — history grows unbounded")
        if out and out > 65536:
            findings.append(
                f"{name}: max_tokens {out} exceeds the 65536 output cap "
                f"declared by the gateways")
    return {"ok": not findings, "findings": findings, "seats": seats}


def _resolve_endpoints(llm_config_path: Path, needed: set) -> dict:
    """Map every needed model slug to its provider credentials, in memory.

    Reads the unified explorateur ``config/.env`` (flat KEY=VALUE lines).
    Variable names are the slug uppercased with non-alphanumerics replaced by
    ``_``.  Slugs sharing one gateway collapse onto a **group pair**: the
    longest sanitized-stem prefix that has both fields wins, so
    ``LLM_FUYAO_*`` alone serves ``fuyao-work`` / ``fuyao-coding`` /
    ``fuyao-data``, and ``LLM_MINIMAX_*`` alone serves every MiniMax slug;
    a per-slug pair (``LLM_FUYAO_WORK_*``) overrides its group.  A prefix
    level registers only when both fields are non-empty (no mixing levels).
    Fail-closed on any needed slug with no complete pair — the error names
    the exact variables to fill.  Key values never enter logs, errors, or
    the preflight payload.
    """
    path = Path(llm_config_path).expanduser()
    if not path.is_file():
        raise RuntimeError(f"LLM credential config not found: {path}")
    entries: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, _, value = line.partition("=")
        name = name.strip()
        value = value.strip().strip('"').strip("'")
        if name and value:
            entries[name] = value

    def _slug_var(slug: str, field: str) -> str:
        stem = re.sub(r"[^A-Za-z0-9]", "_", slug).upper()
        return f"LLM_{stem}_{field}"

    def _slug_stems(slug: str) -> list[str]:
        # Longest sanitized-stem prefix first; the full stem (per-slug pair)
        # outranks every group prefix (LLM_FUYAO_WORK_* over LLM_FUYAO_*).
        parts = re.sub(r"[^A-Za-z0-9]", "_", slug).upper().split("_")
        return ["_".join(parts[:i]) for i in range(len(parts), 0, -1)]

    needed = set(needed)
    found: dict[str, dict[str, str]] = {}
    for slug in needed:
        for stem in _slug_stems(slug):
            base_url = entries.get(f"LLM_{stem}_BASE_URL", "")
            api_key = entries.get(f"LLM_{stem}_API_KEY", "")
            if base_url and api_key:
                found[slug] = {"base_url": base_url, "api_key": api_key}
                break
    missing = sorted(needed - found.keys())
    if missing:
        def _hint(slug: str) -> str:
            stem = re.sub(r"[^A-Za-z0-9]", "_", slug).upper()
            pair = f"LLM_{stem}_BASE_URL + LLM_{stem}_API_KEY"
            group = stem.split("_")[0]
            if group == stem:
                return f"{slug} (fill {pair})"
            return (f"{slug} (fill {pair}, or group pair "
                    f"LLM_{group}_BASE_URL + LLM_{group}_API_KEY)")
        raise RuntimeError(
            "no credentials found for model(s): "
            + ", ".join(_hint(slug) for slug in missing)
            + f" in {path}")
    log.info("resolved LLM endpoints for %d model slug(s)", len(found))
    return found


# ------------------------------------------------------------------- seeding

def _lfs_smudge_overlay(usine_dir) -> dict[str, Path]:
    """LFS-tracked files under the usine prefix -> smudged working-tree
    paths, keyed by prefix-relative posix path.

    ``git archive`` carries LFS-tracked binaries as POINTER text, but the
    usine gate probes its gold assets with real ffprobe/sharp - a pointer
    file is not a valid mp3/png and the gate goes red for a seeding
    reason on EVERY host.  Seed and fixture builders overlay the real
    bytes for exactly these members (the tree is asserted clean, so the
    smudged working-tree bytes ARE the committed content).  Fails closed
    when the local checkout still holds pointer text (a clone without
    ``git lfs pull``): the gold-dependent gate cannot honestly pass
    there, and a seeding that silently ships pointers would be
    fabricating a green-looking red.
    """
    import wave_merge

    ctx = wave_merge._repo_context(Path(usine_dir))
    prefix = str(ctx["prefix"])
    base = prefix if prefix.endswith("/") else prefix + "/"
    ls_argv = ["git", "-C", ctx["toplevel"], "ls-files", "-z"]
    if prefix:
        ls_argv += ["--", base]
    ls = subprocess.run(ls_argv, stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, timeout=300)
    if ls.returncode != 0:
        raise RuntimeError("git ls-files for the LFS overlay failed: "
                           + ls.stderr.decode("utf-8", "replace")[:300])
    paths = [p for p in ls.stdout.split(b"\0") if p]
    if not paths:
        return {}
    ca = subprocess.run(
        ["git", "-C", ctx["toplevel"], "check-attr", "-z", "--stdin",
         "filter"],
        input=b"\0".join(paths), stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, timeout=300)
    if ca.returncode != 0:
        raise RuntimeError("git check-attr for the LFS overlay failed: "
                           + ca.stderr.decode("utf-8", "replace")[:300])
    overlay: dict[str, Path] = {}
    fields = ca.stdout.split(b"\0")
    for i in range(0, len(fields) - 2, 3):
        path_b, attr, value = fields[i], fields[i + 1], fields[i + 2]
        if attr != b"filter" or value != b"lfs":
            continue
        rel = path_b.decode("utf-8", "surrogateescape")
        key = rel[len(base):] if prefix else rel
        worktree = Path(ctx["toplevel"]).joinpath(*PurePosixPath(rel).parts)
        if not worktree.is_file():
            raise RuntimeError(
                f"LFS-tracked gold file is missing from the working tree: "
                f"{rel}")
        with worktree.open("rb") as handle:
            if handle.read(64).startswith(b"version https://git-lfs"):
                raise RuntimeError(
                    f"LFS-tracked gold file is un-smudged pointer text: "
                    f"{rel}; run `git lfs pull` before driving a wave "
                    "(the gate probes these assets with real "
                    "ffprobe/sharp)")
        overlay[key] = worktree
    if overlay:
        log.info("LFS gold overlay: %d file(s) smudged from the working "
                 "tree", len(overlay))
    return overlay


# Process-wide serialization for seed builds, and a HEAD-keyed memo of the
# last build.  Parallel wave guests share one run_root/baselines directory;
# without the lock, two concurrent cold starts both rebuild and the second
# os.replace races the first guest's push_file (bfs10, WinError 32).
_SEED_BUILD_LOCK = threading.Lock()
_SEED_BUILD_MEMO: dict[str, dict] = {}


def _build_seed(usine_dir: Path, write_to: Path | None) -> dict:
    """git-archive the committed usine prefix into an evolution_project seed.

    The seed is the honest baseline: ``git archive HEAD -- <prefix>`` of the
    real usine repository (tracked content only, committed state only).
    Member names are rewritten ``<prefix>/<rel>`` -> ``evolution_project/
    <rel>``; directory members are dropped (extraction creates parents) and
    non-regular members are skipped and counted (symlinks have no faithful
    Windows guest semantics).  LFS-tracked members are overlaid with their
    smudged working-tree bytes (git archive ships pointer text, the gate
    probes the gold assets for real).  With ``write_to`` the compressed
    seed is written atomically next to a manifest; without it nothing is
    written (preflight preview).

    Concurrency (measured 2026-10-19, bfs10): parallel wave guests start
    concurrently, each with its OWN scratch dir, so a per-scratch memo does
    not stop two guests from both missing the cache and building at the same
    time — and the second ``os.replace`` then yanked ``baselines/seed.tgz``
    out from under the first guest's ``push_file`` ([WinError 32], ep001 died
    three seconds after the wave started).  Rebuilds are therefore
    serialized behind a process-wide lock and keyed by HEAD sha: the first
    builder writes, everyone else reuses the existing file after verifying
    its recorded digest.
    """
    import wave_merge  # deferred: _install_paths must run first on odd paths

    usine_dir = Path(usine_dir)
    # NOTE: the merge-safety fail-closed (_assert_preconditions) runs in
    # main(), for the phases that actually merge.  Neither the reuse
    # fast-path below nor the seed build itself may require a clean tree:
    # an operator with uncommitted editor scratch in the real tree still
    # gets the exact committed seed they built before, and a read-only
    # verification never depends on worktree state.  The seed build asks
    # only for a resolvable HEAD.
    ctx = wave_merge._repo_context(usine_dir)
    head = wave_merge._git(["rev-parse", "HEAD"], cwd=ctx["toplevel"]) \
        .stdout.decode("utf-8", "replace").strip()

    # Fast path: the seed for THIS HEAD already exists and its manifest
    # verifies — reuse it, whatever thread got here first.  A concurrent
    # builder holds _SEED_BUILD_LOCK, so a reader either sees the manifest of
    # a fully finished build or misses and joins the locked rebuild.
    if write_to is not None:
        seed_dir = Path(write_to) / "baselines"
        manifest_path = seed_dir / "seed_manifest.json"
        seed_path = seed_dir / "seed.tgz"
        try:
            existing = json.loads(manifest_path.read_text(encoding="utf-8"))
            if (existing.get("head") == head and existing.get("written")
                    and seed_path.is_file() and existing.get("sha256")
                    and existing.get("bytes") is not None
                    and hashlib.sha256(seed_path.read_bytes()).hexdigest()
                    == existing["sha256"]
                    and seed_path.stat().st_size == existing["bytes"]):
                info = dict(existing)
                info["reused"] = True
                return info
        except (OSError, ValueError):
            pass

    # The seed is a `git archive HEAD` of the prefix: it never reads the
    # worktree, so a dirty worktree cannot change a single byte of it.  The
    # merge-safety gate (_assert_preconditions) runs in main(), before this,
    # for the phases that actually merge.  Here the seed only needs a
    # resolvable HEAD — an operator with uncommitted editor scratch still
    # gets the exact committed seed, and the DRS (which never merges) is
    # not blocked by work it could not have damaged anyway.
    seed_source = wave_merge._assert_seedable(ctx, usine_dir)
    head = seed_source["head"]
    with _SEED_BUILD_LOCK:
        # Re-check under the lock: a parallel thread may have finished the
        # rebuild while this one waited on the git-archive probe above.
        if write_to is not None:
            try:
                existing = json.loads((Path(write_to) / "baselines"
                                       / "seed_manifest.json")
                                      .read_text(encoding="utf-8"))
                seed_path = Path(write_to) / "baselines" / "seed.tgz"
                if (existing.get("head") == head and existing.get("written")
                        and seed_path.is_file() and existing.get("sha256")
                        and hashlib.sha256(seed_path.read_bytes()).hexdigest()
                        == existing["sha256"]):
                    info = dict(existing)
                    info["reused"] = True
                    _SEED_BUILD_MEMO[head] = info
                    return info
            except (OSError, ValueError):
                pass
        return _build_seed_locked(usine_dir, head, ctx, write_to)


def _build_seed_locked(usine_dir: Path, head: str, ctx: dict,
                       write_to: Path | None) -> dict:
    """Rebuild the seed archive.  Caller holds _SEED_BUILD_LOCK."""
    prefix = str(ctx["prefix"])
    base = prefix if prefix.endswith("/") else prefix + "/"
    argv = ["git", "-C", ctx["toplevel"], "archive", "--format=tar", "HEAD"]
    if prefix:
        argv += ["--", base]
    try:
        proc = subprocess.run(argv, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=300)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"git archive could not run: {exc}") from exc
    if proc.returncode != 0:
        raise RuntimeError(
            "git archive HEAD failed (exit "
            f"{proc.returncode}): {proc.stderr.decode('utf-8', 'replace')[:300]}")

    out = io.BytesIO()
    files = 0
    skipped = 0
    lfs_files = _lfs_smudge_overlay(usine_dir)
    lfs_overlaid = 0
    with (tarfile.open(fileobj=io.BytesIO(proc.stdout), mode="r:") as src,
          tarfile.open(fileobj=out, mode="w",
                       format=tarfile.GNU_FORMAT) as dst):
        for member in src:
            if member.isdir():
                # git archive also emits the pathspec directory itself
                # ("usine/"); extraction creates parents, so skip all dirs.
                continue
            name = PurePosixPath(member.name).as_posix()
            if prefix:
                if not name.startswith(base):
                    raise RuntimeError(
                        f"seed archive member outside the prefix: {member.name!r}")
                rel = name[len(base):]
            else:
                rel = name
            if not rel or rel.endswith("/"):
                continue
            if not member.isfile():
                skipped += 1
                continue
            fresh = copy.copy(member)
            fresh.name = "evolution_project/" + rel
            overlay_path = lfs_files.get(rel)
            if overlay_path is not None:
                payload = overlay_path.read_bytes()
                fresh.size = len(payload)
                dst.addfile(fresh, io.BytesIO(payload))
                lfs_overlaid += 1
            else:
                dst.addfile(fresh, src.extractfile(member))
            files += 1
    if not files:
        raise RuntimeError("the usine seed would be empty")
    data = gzip.compress(out.getvalue(), compresslevel=1, mtime=0)
    sha = hashlib.sha256(data).hexdigest()
    info = {
        "head": head,
        "prefix": prefix or "(repo root)",
        "members": files,
        "skipped_non_regular": skipped,
        "lfs_overlaid": lfs_overlaid,
        "bytes": len(data),
        "sha256": sha,
        "written": False,
        "path": None,
    }
    if write_to is not None:
        seed_dir = Path(write_to) / "baselines"
        seed_dir.mkdir(parents=True, exist_ok=True)
        seed_path = seed_dir / "seed.tgz"
        temporary = seed_path.with_name(seed_path.name + ".rsiagent-part")
        temporary.write_bytes(data)
        os.replace(temporary, seed_path)
        info["written"] = True
        info["path"] = str(seed_path)
        _write_json_atomic(seed_dir / "seed_manifest.json", info)
        log.info("usine seed rebuilt at HEAD %s: %d member(s), %d bytes",
                 head[:10], files, len(data))
    _SEED_BUILD_MEMO[head] = info
    return info


def _stage_harness_link_targets(env, usine_dir) -> None:
    """Stage the out-of-tree ``link:`` devDependencies where the guest tree
    resolves them.

    ``packages/dsh-plugin`` typechecks against two harness packages that
    live OUTSIDE the usine checkout (``link:../../../../../deepseek-harness/
    ...`` devDependencies).  The seeded guest tree sits deeper than the
    real checkout (disk_root/home/user/evolution_project/...), and the
    ``..`` walk from there anchors at the guest disk root on both
    substrates (POSIX: the scratch disk path; Windows: the subst drive
    root) - so the shared harness checkout root must exist there.  It is
    staged as a single symlink (POSIX) to the real checkout, not copied:
    the harness' internal per-package ``node_modules`` are relative
    symlinks into sibling packages, so only the intact checkout resolves
    the full type closure.  This grants no new reach: the worktree guest
    is a path-REWRITE illusion, not an OS sandbox - guest programs
    already resolve any absolute host path, and the publish/login red
    lines are enforced by the VM facade and gates, not by filesystem
    isolation.  Scratch release stays safe: rmtree never follows the
    link (rmtree_force chmods a link's PARENT, never through the link).
    Fail-closed before any token is spent: an unresolvable harness
    checkout means every wave on this host is structurally doomed to a
    gate-red typecheck.
    """
    dsh_dir = Path(usine_dir) / "packages" / "dsh-plugin"
    manifest_path = dsh_dir / "package.json"
    try:
        dev_deps = json.loads(manifest_path.read_text(
            encoding="utf-8")).get("devDependencies", {})
    except (OSError, ValueError) as exc:
        raise RuntimeError(
            f"cannot read {manifest_path} to resolve the harness link "
            f"dependencies: {exc}") from exc
    disk_root = Path(str(getattr(env, "disk_root", "")))
    if not disk_root.is_dir():
        raise RuntimeError("usine seeding VM has no disk_root to stage "
                           "harness link targets into")
    links = []
    for name, spec in sorted(dev_deps.items()):
        spec = str(spec)
        if not spec.startswith("link:"):
            continue
        rel = PurePosixPath(spec[len("link:"):])
        rel_parts = list(rel.parts)
        anchor_at = next(
            (i for i, p in enumerate(rel_parts) if p != ".."), None)
        if anchor_at is None:
            raise RuntimeError(
                f"harness link dependency {name} has a bare relative "
                f"specifier: {spec!r}")
        if ".." in rel_parts[anchor_at + 1:]:
            raise RuntimeError(
                f"harness link dependency {name} has an unanchored "
                f"relative specifier: {spec!r}")
        # Leading ``..``s are the walk up to the shared checkout parent;
        # everything after them must descend from a single anchor name
        # (the one directory staged at the guest disk root).
        parts = rel_parts[anchor_at:]
        source = (dsh_dir / spec[len("link:"):]).resolve()
        if not (source / "package.json").is_file():
            raise RuntimeError(
                f"harness link dependency {name} does not resolve to a "
                f"package (specifier {spec!r} -> {source}); the guest-side "
                "pnpm gate would be structurally red - stage the harness "
                "checkout the usine tree links against")
        root_source = source
        for _ in parts[1:]:
            root_source = root_source.parent
        links.append((name, parts, root_source))
    staged_roots = 0
    roots_done = set()
    for name, parts, root_source in links:
        dest = disk_root.joinpath(*parts)
        if (dest / "package.json").is_file():
            continue
        root_name = parts[0]
        dest_root = disk_root / root_name
        if root_name not in roots_done:
            roots_done.add(root_name)
            if dest_root.is_symlink() or dest_root.exists():
                raise RuntimeError(
                    f"harness anchor {dest_root} already exists on the "
                    "guest disk but is not the staged link layout")
            if os.name == "nt":
                raise RuntimeError(
                    "harness link-anchor staging needs a directory "
                    "junction on Windows (os.symlink requires elevated "
                    "privileges; _winapi.CreateJunction is the port) - "
                    "port it on the wave host before the first real wave "
                    "there (the guest gate is structurally red without "
                    "the anchor)")
            os.symlink(root_source, dest_root, target_is_directory=True)
            staged_roots += 1
        if not (dest / "package.json").is_file():
            raise RuntimeError(
                f"harness link dependency {name} does not resolve "
                f"through the staged anchor {dest_root} -> {root_source}"
                "; the guest-side pnpm gate would be structurally red")
    if staged_roots:
        log.info("usine harness link anchor staged into the guest disk "
                 "root: %d root(s)", staged_roots)


def _harness_staging_vm_factory(inner_factory, state: dict, *, seed: bool = False):
    """Wrap the VM factory: stage the harness ``link:`` anchor for EVERY
    guest, not just the seed-time one.  Later nights (Actor, Verifier,
    memory) replay the captured tree through the engine's provisioning
    stage path, which never passes through ``_seed_guest`` - but every
    guest that replays the usine tree and might run the pnpm gate needs
    the anchor at its own disk root.  Staging is idempotent and skipped
    for non-Worktree VMs (no scratch).

    ``seed=True`` additionally pushes the git-archive seed at CREATION
    time rather than waiting for the first fixture capture.  That wait was
    a deadlock, measured on 2026-10-19: the Curriculum Agent authors a wave
    by inspecting the repository it must write projects against, but on a
    blank guest it finds nothing (``candidates: 0``) and spends whole
    round trips rediscovering where the tree lives — each of those turns
    is a full ``reasoning_effort: max`` generation, and two of them
    exhausted the whole run ceiling before the wave was ever published.

    Seeding at creation removes the chicken-and-egg: the Curriculum's first
    iteration already sees the real repository.  ``_seed_guest`` is
    idempotent (per-scratch cache, extract WITHOUT wiping), so the later
    capture-time seed is a no-op and the capture-time toolchain probe still
    runs exactly once per guest.
    """
    def factory():
        pair = inner_factory()
        vm = pair[1] if isinstance(pair, tuple) else pair
        env = getattr(vm, "env", None)
        scratch = str(getattr(env, "scratch", "")) if env is not None else ""
        if scratch:
            _stage_harness_link_targets(env, state["usine_dir"])
            if seed:
                _seed_guest(vm, state)
        return pair
    return factory


def _seed_guest(vm, state: dict) -> None:
    """Push + extract the seed into one guest (idempotent per wave VM)."""
    env = getattr(vm, "env", None)
    scratch = str(getattr(env, "scratch", "")) if env is not None else ""
    if not scratch:
        raise RuntimeError(
            "usine seeding requires a WorktreeEnv-backed VM (no scratch)")
    info = state["cache"].get(scratch)
    if info is None:
        info = _build_seed(state["usine_dir"], Path(state["run_root"]))
        state["cache"][scratch] = info
    ok, error = vm.push_file(info["path"], "/dev/shm/usine-seed.tgz")
    if not ok:
        raise RuntimeError(f"usine seed push failed: {error}")
    out = vm.run_command(
        "stat -c %s /dev/shm/usine-seed.tgz; "
        "sha256sum /dev/shm/usine-seed.tgz | cut -d' ' -f1",
        timeout=120) or ""
    lines = [line.strip() for line in out.strip().splitlines()
             if line.strip()]
    if (len(lines) < 2 or lines[0] != str(info["bytes"])
            or lines[1] != info["sha256"]):
        raise RuntimeError("usine seed failed guest size/digest verification")
    # Extract over /home/user WITHOUT wiping: the Curriculum scaffold keeps
    # its task-specific extras and the baseline wins file collisions.
    out = vm.run_command(
        "tar xzf /dev/shm/usine-seed.tgz -C /home/user && "
        "rm -f /dev/shm/usine-seed.tgz; echo USINE_SEED_RC=$?",
        timeout=900) or ""
    if "USINE_SEED_RC=0" not in out:
        raise RuntimeError(f"usine seed extraction failed: {out[-400:]}")
    # Guest toolchain probe: the Actor reaches node only through bash-wrapped
    # pnpm/node programs, so a guest without the toolchain cannot even
    # attempt the gate — probe once per seeded guest, fail-closed BEFORE any
    # token is spent on waves that are structurally doomed to gate-red.
    out = vm.run_command(
        "node --version; pnpm --version; echo USINE_TOOLCHAIN_RC=$?",
        timeout=300) or ""
    lines = [line.strip() for line in out.strip().splitlines()
             if line.strip()]
    if (len(lines) < 3 or lines[-1] != "USINE_TOOLCHAIN_RC=0"):
        raise RuntimeError(
            "guest toolchain probe failed: node/pnpm are not runnable in "
            "the seeded guest (waves need Node >= "
            f"{_NODE_MIN_MAJOR} and pnpm >= {_PNPM_MIN_MAJOR} inside the "
            "guest image); probe tail: " + out[-300:])
    node_major = _version_major(lines[0])
    pnpm_major = _version_major(lines[1])
    if node_major is None or node_major < _NODE_MIN_MAJOR:
        raise RuntimeError(
            f"guest node too old for the pnpm gate: {lines[0]!r} (need "
            f">= {_NODE_MIN_MAJOR})")
    if pnpm_major is None or pnpm_major < _PNPM_MIN_MAJOR:
        raise RuntimeError(
            f"guest pnpm too old for the workspace gate: {lines[1]!r} "
            f"(need >= {_PNPM_MIN_MAJOR})")


# capture 剪枝：guest 工作树里可再生重物不入 capture。usine 是 pnpm TS
# monorepo：node_modules（根 + 每包嵌套，万级符号链接）与 dist（`pnpm test`
# 重建 dsh-plugin 的构建产物）由 install/build 完全再生，不是工作成果；
# build（gitignored 证据/再生输出根，如 publish 测试的 build/publish-verify
# 证据副本）同理——无栏杆时 guest 门禁的未跟踪副作用会混进候选 delta。
# 不剪枝会炸 120s tar 超时/无界 fetch/回放逐文件校验，且未设栏的第三方
# 内容会撑爆 UsineAudit 审计面。与 wave_merge.EXCLUDED_PARTS 同一约定，
# 两头对称：capture 进不来的东西，合并侧也不会试图捡回去。
_CAPTURE_EXCLUDE_PARTS = ("node_modules", "dist", "build")


def _seeded_capture(inner, state: dict):
    """Wrap hooks.capture_project: seed the guest at fixture-capture time only.

    ``phase1-project-*`` captures stage the Curriculum fixture and then
    capture the merge baseline, so the seed merges into the tree right
    here — the captured fixture (and every branch VM replaying it) becomes
    scaffold UNION baseline.  Candidate captures (``phase1-candidate-*``)
    and blocked-draft captures are forwarded untouched.  Every capture —
    fixture and candidate alike — prunes the regenerable heavy directories
    declared in ``_CAPTURE_EXCLUDE_PARTS`` (the engine seam is a no-op when
    the tree carries no such directories, so the pruned fixture and the
    pruned candidate stay symmetric).

    THE DRS NEEDS THE SAME SEAM, AND ITS OWN KEY.  The serial core (Phase 2)
    captures the Curriculum's fixture as ``ep<N>-fixtures`` and then REPLAYS
    that capture onto the Actor's freshly-reset guest.  The seed pushed at
    VM creation does NOT survive that reset — ``_reset_null_vm`` calls
    ``env.reset()``, which restores the guest from its snapshot and takes
    the whole seeded tree with it — so without a seed at the DRS's capture
    seam the Actor's owned root holds ONLY the Curriculum's fixture files:
    no package.json, no packages/, no source.  The Actor then has no
    repository to edit, and it burns its whole time budget hunting for one
    (measured 2026-10-20, bfs16h: the Actor probed guest paths, the pnpm
    store, and OTHER runs' stale guest worktrees — and found the monorepo
    only in a previous run's guest, at a different HEAD).  Every DRS run
    before this died there, with an unchanged memory tree.

    Seeding at the DRS's fixture capture seam makes the capture
    scaffold UNION baseline, exactly like Phase 1 — and the replay then
    hands the Actor the real repository.  The Curriculum's own publish
    checks still pass: the seed lands AFTER the Curriculum published, so
    its "no code files in the owned root" self-check is unaffected.
    """
    def capture_project(vm, key, host_dir, *args, **kwargs):
        if isinstance(key, str) and _is_fixture_capture_key(key):
            _seed_guest(vm, state)
        kwargs.setdefault("exclude_parts", _CAPTURE_EXCLUDE_PARTS)
        return inner(vm, key, host_dir, *args, **kwargs)
    return capture_project


# Capture keys that carry the Curriculum's staged fixture — the one moment
# the guest must hold the seeded baseline.  Phase 1 names it
# ``phase1-project-<n>``; the DRS's serial core names it ``ep<n>-fixtures``.
# Candidate captures (``phase1-candidate-*``, ``ep<n>-candidate-<n>``) are
# NEVER seeded: they capture the Actor's tree, which already carries the
# baseline, and seeding them would be a no-op at best.
_DRS_FIXTURE_CAPTURE_KEY = re.compile(r"^ep\d{3}-fixtures$")


def _is_fixture_capture_key(key: str) -> bool:
    """True for the capture keys that stage a fixture (and need the seed)."""
    return bool(key.startswith("phase1-project-")
                or _DRS_FIXTURE_CAPTURE_KEY.match(key))


# Two files that only exist if the seeded baseline was really extracted.
# ``package.json`` is the monorepo root; ``tools.ts`` is the TARGET MENU's
# first target, so a tree carrying it is the real repository.
_BASELINE_MARKERS = (
    "evolution_project/package.json",
    "evolution_project/packages/dsh-plugin/src/tools.ts",
)


def _baseline_present(vm) -> bool:
    """Ask the guest whether the seeded baseline is really there."""
    probe = " ".join(f'"/home/user/{marker}"' for marker in _BASELINE_MARKERS)
    out = vm.run_command(
        f"for f in {probe}; do test -f \"$f\" || "
        "{ echo BASELINE_MISSING:$f; exit 1; }; done; echo BASELINE_OK",
        timeout=120) or ""
    return "BASELINE_OK" in out


def _baseline_guarded_replay(inner, state: dict):
    """Wrap hooks.replay_project: fail closed if the replay lost the baseline.

    The replay is the last seam before the Actor starts.  If the tree it
    restored carries no seeded repository, the Actor cannot do the project
    at all — it will spend its entire time budget looking for code that is
    not there.  That is a WIRING gap, and (measured 2026-10-20) a wiring gap
    must cost seconds, not a thirty-minute run: this guard turns it into an
    immediate, named failure.
    """
    def replay_project(vm, host_dir, *args, **kwargs):
        result = inner(vm, host_dir, *args, **kwargs)
        if not result.get("ok"):
            return result
        if not _baseline_present(vm):
            raise RuntimeError(
                "the replayed project tree carries no seeded baseline "
                f"(missing one of {_BASELINE_MARKERS}): the Actor would have "
                "no repository to edit and would burn its whole time budget "
                "hunting for one. This is a wiring gap, not a seat failure.")
        return result
    return replay_project


# -------------------------------------------------------------------- corpus

# The corpus is FIXED for the whole run (distribution shingles only, never
# extended mid-run): stock Phase 1 feeds every prior project text verbatim
# back into later Curriculum prompts while _audit_prompt authorizes only the
# target direction, so per-wave corpus growth would quarantine the next
# wave's first authoring segment.  extend_corpus stays available in
# usine_hooks for operator-driven flows, but this orchestrator never grows
# the corpus between waves.


# ------------------------------------------------------ distribution fence

# First-party packages this run can import: every string literal in them can
# reach an audited surface (system prompts, wave-authoring and verifier
# templates, infra strings replayed into transcripts).  tests/ tools/
# benchmarks/ are never imported by the wave loop and stay out of the fence.
_FENCE_PY_PACKAGES = ("explore", "core", "env", "config", "llm")
_FENCE_BINARY_HEAD = 8192      # mirrors UsineAudit.captured's binary cutoff


def _fence_texts(theatre: Path, usine_dir: Path, stats: dict):
    """Yield (label, text) for every source the fence must clear.

    Mirrors the audit's decode rules exactly: content is decoded
    utf-8/ignore, and a NUL within the first 8 KiB marks a binary member
    whose CONTENT the capture audit skips.  Names stay audited, so the
    rewritten capture member name is yielded for every tracked file.
    """
    import wave_merge

    ctx = wave_merge._repo_context(usine_dir)
    prefix = str(ctx["prefix"])
    base = prefix if prefix.endswith("/") else prefix + "/"
    argv = ["git", "-C", ctx["toplevel"], "ls-files", "-z"]
    if prefix:
        argv += ["--", base]
    try:
        proc = subprocess.run(argv, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=120)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"git ls-files could not run: {exc}") from exc
    if proc.returncode != 0:
        raise RuntimeError(
            "git ls-files failed (exit "
            f"{proc.returncode}): {proc.stderr.decode('utf-8', 'replace')[:300]}")
    tracked = [name for name in
               proc.stdout.decode("utf-8", "surrogateescape").split("\0")
               if name]
    if not tracked:
        raise RuntimeError("the usine prefix has no tracked files to fence")
    stats["usine_tracked"] = len(tracked)
    for name in tracked:
        if prefix:
            if not name.startswith(base):
                raise RuntimeError(
                    f"tracked usine path outside the prefix: {name!r}")
            rel = name[len(base):]
        else:
            rel = name
        # The seed strips the prefix (members are evolution_project/<rel>)
        # and capture member names are audited as text.
        yield "usine:capture-name", "evolution_project/" + rel
        path = Path(ctx["toplevel"]) / name
        try:
            data = path.read_bytes()
        except OSError as exc:
            raise RuntimeError(
                f"tracked usine file is unreadable: {name}") from exc
        if b"\x00" in data[:_FENCE_BINARY_HEAD]:
            stats["usine_binary_skipped"] += 1
            continue
        yield "usine:seeded-text", data.decode("utf-8", "ignore")
    for package in _FENCE_PY_PACKAGES:
        for path in sorted((theatre / package).rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            stats["theatre_py"] += 1
            yield f"theatre:{package}", path.read_text(
                encoding="utf-8", errors="ignore")
    for path in sorted(_HERE.glob("*.py")):
        stats["adapter_py"] += 1
        yield "adapter:code", path.read_text(encoding="utf-8", errors="ignore")
    for path in sorted((_HERE / "config" / "roles-usine").glob("*.yaml")):
        stats["role_yaml"] += 1
        yield "adapter:role-config", path.read_text(
            encoding="utf-8", errors="ignore")


def _check_distribution_fences(distribution: str, theatre: Path,
                               usine_dir: Path) -> dict:
    """Fail closed unless the distribution is 8-gram-disjoint from every
    text that flows into audited surfaces.

    The corpus IS the distribution's shingles, and the stock audit exempts
    only the target direction (wave prompts) or the project instruction
    (captures) - never the distribution itself: one shared 8-gram with
    seeded usine text, a capture member name, a stock/adapted prompt
    template, a role system_extra, or the transport note would trip audits
    on every wave.  Both entrypoints and every resume run this gate BEFORE
    anything is written or spent; resume re-runs it after pending merges
    too (merged candidates move HEAD, and the next wave captures from the
    new tree).
    """
    import usine_hooks

    grams = usine_hooks._shingles(distribution)
    if not grams:
        raise RuntimeError(
            "the distribution yields no word 8-grams (write it as English "
            "prose: the [a-z0-9]+ tokenizer produces zero shingles from CJK "
            "text, which would silently disable the leakage fence)")
    stats = {"usine_binary_skipped": 0, "theatre_py": 0,
             "adapter_py": 0, "role_yaml": 0}
    collisions: dict = {}
    sources = 0
    for label, text in _fence_texts(theatre, usine_dir, stats):
        sources += 1
        for hit in usine_hooks._shingles(text) & grams:
            collisions.setdefault(hit, set()).add(label)
    if collisions:
        detail = "; ".join(
            f"{sorted(labels)}: {shingle!r}"
            for shingle, labels in sorted(collisions.items())[:5])
        raise RuntimeError(
            f"distribution shares {len(collisions)} instruction shingle(s) "
            f"with audited surfaces - reword the distribution: {detail}")
    result = {"status": "clear", "distribution_shingles": len(grams),
              "audited_sources": sources, **stats}
    log.info("distribution fence clear: %d shingle(s) disjoint from %d "
             "audited source(s) (%d tracked usine file(s), %d binary "
             "skipped)", len(grams), sources, stats["usine_tracked"],
             stats["usine_binary_skipped"])
    return result


# ----------------------------------------------------------------------- CLI

def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-name", required=True)
    parser.add_argument(
        "--distribution-file", default=str(DEFAULT_DISTRIBUTION),
        help=("UTF-8 target-direction/distribution description; seeds the "
              "instruction corpus and steers the Curriculum"))
    parser.add_argument(
        "--target-query-conditioned", action="store_true",
        help=("derive diverse Phase-1 exploration from the supplied exact "
              "query; the unchanged target itself remains reserved for "
              "Phase 2"))
    parser.add_argument(
        "--phase", choices=("1", "2"), default="1",
        help=("1 = BRS waves (parallel breadth, the default); "
              "2 = DRS deep recursion (sequential practice over the "
              "memory Phase 1 produced, per RSIAgent 2.2).  Phase 2 "
              "requires its own --execute token and reads the Phase-1 "
              "run root, so it can only deepen memory that exists."))
    parser.add_argument("--project-budget", type=int, default=8)
    parser.add_argument(
        "--run-ceiling-secs", type=int,
        default=None,
        help=("hard time ceiling for the whole run, in seconds "
              "(default: 1500 = twenty-five minutes for Phase 1, 1800 = "
              "thirty minutes for the DRS; the ceiling follows the measured "
              "gateway latency and the measured cost of the phase's seats, "
              "and a self-evolution run must stay iterable).  The budget is "
              "split across the seats, each seat's wall_clock_secs is "
              "tightened to its slice, and the wave loop stops at the first "
              "COMPLETE-WAVE boundary past the ceiling. "
              "Recorded in the manifest — the ceiling is always auditable."))
    parser.add_argument(
        "--time-budget-allow-over", action="store_true",
        help=("proceed even when the planned budget does not fit the "
              "ceiling.  Off by default: an unrunnable budget fails closed "
              "at preflight rather than producing a wave that cannot "
              "finish.  Use only with a larger --run-ceiling-secs."))
    parser.add_argument(
        "--checkpoints", default=None,
        help=("comma-separated memory checkpoint indices; defaults to "
              "0,2,4,8 scaled down to the project budget (a smaller budget "
              "must not crash parsing with an out-of-range checkpoint)"))
    parser.add_argument(
        "--max-parallel", type=int, default=4,
        help=("host scheduling capacity for a Curriculum-authored wave; "
              "this does not prescribe or truncate the wave width"))
    parser.add_argument(
        "--root", default=str(DEFAULT_RUNS_ROOT),
        help=("run-lineage root, OUTSIDE every repository (endpoints.json "
              f"with live credentials is generated there); default "
              f"{DEFAULT_RUNS_ROOT}"))
    parser.add_argument("--usine-dir", default=str(DEFAULT_USINE_DIR))
    parser.add_argument(
        "--gate-argv", nargs="+", default=list(DEFAULT_GATE_ARGV),
        help=("the offline verification gate executed from the usine "
              "directory before every merge commit"))
    parser.add_argument("--gate-timeout", type=float, default=1800.0)
    parser.add_argument(
        "--gate-install", action="store_true",
        help=("let the gate preflight run `pnpm install --frozen-lockfile "
              "--prefer-offline` inside the usine tree when node_modules is "
              "missing (default: fail closed and print the fix command; "
              "ignored by the read-only --preflight report)"))
    parser.add_argument(
        "--llm-config", default=str(DEFAULT_LLM_CONFIG),
        help=("unified explorateur config/.env (LLM_<SLUG>_BASE_URL / "
              "LLM_<SLUG>_API_KEY pairs; see config/env.sample)"))
    parser.add_argument(
        "--resume-completed-boundary", action="store_true",
        help=("resume an infrastructure-stopped lineage only when every "
              "accepted project is durably closed and the persistent "
              "Curriculum transcript is intact"))
    parser.add_argument(
        "--memory-seed", default="",
        help=("seed this run's memory tree from an existing one (a "
              "directory of .md records).  Phase 1 normally starts from an "
              "empty tree; seeding it lets a wave run ON TOP of what an "
              "earlier phase learned, so the Actor starts with the "
              "hard-won records instead of rediscovering them.  The DRS "
              "(Phase 2) already seeds itself from Phase 1."))
    parser.add_argument(
        "--pin-projects", default="", metavar="CURRICULUM_DECISION_JSON",
        help=("pin every wave's projects to an existing "
              "`curriculum_decision.json` (from this run or an earlier one).  "
              "**Needed to compare two arms on the SAME task**: the Curriculum "
              "picks from a fixed menu with no deterministic switch, so two arms "
              "can otherwise draw different projects -- and a memory comparison "
              "across different tasks measures task difficulty, not memory.  "
              "Only the project choice is replaced; SATURATED / STALLED still "
              "come from the engine, and the pinned file must pass the engine's "
              "own parser.  **Cross-run use needs --fixture-from**: the pinned "
              "project's fixture lives in the guest and dies with it, so a "
              "decision from an EARLIER run only replays if you also point "
              "--fixture-from at that run's episode directory (it holds the "
              "archived `fixtures/materials.tgz`). Without it the run fails "
              "fast with PinFixtureMissing instead of dying later in `cp`."))
    parser.add_argument(
        "--fixture-from", default="", metavar="EPISODE_DIR",
        help=("with --pin-projects: rebuild the pinned project's fixture from an "
              "earlier run's episode directory (the one holding "
              "`fixtures/materials.tgz`).  **This is what makes a cross-run "
              "comparison possible**: the fixture lives in the guest and dies "
              "with it, but `_capture_wave_fixtures` archived a copy in every "
              "episode, and its tar top-level entry IS `evolution_project/`.  "
              "Without this, pinning a project from an earlier run fails with "
              "PinFixtureMissing."))
    parser.add_argument(
        "--merge-drs", action="store_true",
        help=("merge the DRS episode's candidate into the usine tree "
              "(Phase 2 only).  The DRS's serial core closes an episode "
              "with PROJECT_CLOSED, so the wave-merge sink never fires and "
              "the candidate normally stays in the run root.  With this "
              "flag the candidate goes through the same delta, drift, gate, "
              "commit and tag machinery as a breadth wave — the gate is "
              "re-run against the REAL tree before it lands there."))
    parser.add_argument(
        "--merge-tag-prefix", default="theatre/wave",
        help=("tag namespace for merged candidates: the wave tag is "
              "<prefix>-<wave_index>.  Wave indexes are PER LINEAGE (a "
              "fresh run starts at 1), so a second lineage collides with "
              "the first at theatre/wave-1 — the existing tag wins and "
              "the new commit is left untagged, which is exactly the "
              "'nobody can tell which change came from where' failure.  "
              "Give each lineage its own prefix when running more than "
              "once (e.g. --merge-tag-prefix theatre/bfs17)."))
    parser.add_argument(
        "--allow-high-latency", action="store_true",
        help=("run even when the latency preflight finds a seat whose "
              "historical max exceeds the planned slice (the default is to "
              "refuse: a slice absorbs variance only so far, and the gateway's "
              "first-response latency has been measured at 50.6s, 108.2s, "
              "138.7s, 322s and over 300s).  The risk is recorded in the "
              "manifest either way - an allowed risk is never a silent one."))
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument(
        "--preflight", action="store_true",
        help=("print the readiness payload and exit without writing "
              "anything (no endpoints file, no run root, no corpus)"))
    action.add_argument("--execute", default="", help=EXECUTE_ACK)
    return parser


def main(argv: list | None = None) -> int:
    args = _parser().parse_args(argv)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s")
    if args.project_budget < 0:
        raise RuntimeError("--project-budget must be nonnegative")
    if args.max_parallel < 1:
        raise RuntimeError("--max-parallel must be positive")
    if not args.gate_argv:
        raise RuntimeError("--gate-argv must name the offline gate command")
    if args.merge_drs and args.phase != "2":
        # The DRS is the only phase whose candidate never reaches the
        # repository on its own: its serial core closes an episode with
        # PROJECT_CLOSED, so the wave-merge sink never fires.  Phase 1
        # merges through that sink already; --merge-drs there would be a
        # second, redundant path to the same merge.
        raise RuntimeError(
            "--merge-drs is a Phase-2 (DRS) feature: Phase 1 already merges "
            "its waves through the event sink")
    memory_seed: Path | None = None
    if args.memory_seed:
        memory_seed = Path(args.memory_seed).expanduser().resolve(strict=False)
        if not memory_seed.is_dir():
            raise RuntimeError(
                f"--memory-seed must be a directory of memory records: "
                f"{memory_seed}")
        if not any(path.is_file() for path in memory_seed.rglob("*")):
            raise RuntimeError(
                f"--memory-seed holds no files: {memory_seed}")
    memory_seed_info = (_inspect_memory_seed(memory_seed)
                        if memory_seed is not None else None)
    tag_prefix = (args.merge_tag_prefix or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9/_-]*", tag_prefix):
        raise RuntimeError(
            f"--merge-tag-prefix must be a nonempty tag path of "
            f"[A-Za-z0-9/_-], got {args.merge_tag_prefix!r}")
    checkpoints = _parse_checkpoints(
        args.checkpoints if args.checkpoints is not None
        else _default_checkpoints(args.project_budget),
        args.project_budget)

    theatre = _install_paths()
    import latency_budget
    import spread
    import time_budget
    import verifier_adapter
    # Before any guest exists: the guest inherits THIS process's PATH, so a
    # stale host PATH would hand every guest a pnpm that fails the gate.
    _prepend_standalone_pnpm()
    verifier_adapter.install_verifier_adapter()
    import guest_env            # noqa: F401  (substrate; registers atexit net)
    import usine_hooks
    import wave_merge
    _install_actor_prompt_patch()
    _wave_host_no_browser()
    # 钉住题目：让两条臂拿同一份 curriculum 决策，否则「记忆有没有害」问不出来。
    # 装在这里（而不是 wave 内部）是因为它 wrap 的是引擎的 `_author_wave`，
    # 必须在任何波次启动前装好，且只装一次。
    if args.pin_projects:
        import pin_curriculum
        pinned = pin_curriculum.load_pinned(
            Path(args.pin_projects).expanduser().resolve(strict=True))
        pin_curriculum.install(
            pinned,
            fixture_from=(Path(args.fixture_from).expanduser().resolve(strict=True)
                          if args.fixture_from else None))
        log.info("%s", pin_curriculum.describe(pinned))

    distribution_path = _resolve_input_file(
        args.distribution_file, repo_root=_HERE)
    distribution = distribution_path.read_text(encoding="utf-8").strip()
    if not distribution:
        raise RuntimeError("distribution description is empty")
    usine_dir = Path(args.usine_dir).expanduser().resolve(strict=True)
    if not usine_dir.is_dir():
        raise RuntimeError(f"usine directory is missing: {usine_dir}")
    run_root = _safe_phase_root(args.root, args.run_name, args.phase)
    phase_label = ("usine_production_line_rsi_waves"
                   if args.phase == "1"
                   else "usine_production_line_rsi_drs")

    configs, role_paths, escalation_cfg = _load_roles()
    # Phase 2 runs the DRS curriculum seat instead of the Phase-1 one.  The
    # swap happens HERE, before the lineup check and before apply_slices, so
    # both the lineup invariants and the slice plan are evaluated against the
    # seat this run will actually use — a slice applied to the wrong config
    # is a silent budget error (the bfs16/curriculum-280-vs-400 class of
    # bug).  Phase 1 keeps curriculum-usine.yaml untouched.
    configs, role_paths = _select_phase_seats(configs, role_paths, args.phase)
    lineup = _check_lineup(configs, escalation_cfg)

    # Time budget: plan the whole run BEFORE any token is spent, apply the
    # per-seat slices to the loaded configs, and fail closed when the plan
    # cannot fit the ceiling.  A run with no ceiling is how both recorded
    # waves burned ~40 minutes on infrastructure failures.
    if args.run_ceiling_secs is None:
        # Phase 1 keeps the operator's twenty-five minutes.  The DRS is a
        # different job with a measured cost of its own (see
        # time_budget.DRS_RUN_CEILING_SECS), so it carries its own ceiling.
        args.run_ceiling_secs = (
            time_budget.DRS_RUN_CEILING_SECS if args.phase == "2"
            else time_budget.DEFAULT_RUN_CEILING_SECS)
    elif args.run_ceiling_secs != time_budget.DEFAULT_RUN_CEILING_SECS:
        log.info("run ceiling overridden to %ds (recorded in the manifest)",
                 args.run_ceiling_secs)
    # Phase 1 and Phase 2 get their OWN slice plan.  The DRS is the paper's
    # deep recursion over the memory Phase 1 produced: measured on
    # 2026-10-20, its Actor seat needs ~670s (the Phase-1 580s slice killed
    # it one iteration before it published), and its memory phase is a cost
    # of its own.  One shared allocation cannot serve both jobs.
    slice_plan = (time_budget.DRS_SLICES if args.phase == "2"
                  else time_budget.DEFAULT_SLICES)
    budget_plan = time_budget.plan_budget(
        ceiling_secs=args.run_ceiling_secs,
        projects=max(1, min(args.project_budget or 1, args.project_budget or 1)),
        slices=slice_plan)
    applied_seat_wall = time_budget.apply_slices(configs, budget_plan)

    # The manifest is the resume gate's byte-for-byte comparison, and the
    # spread constraint is derived from the git HEAD — which MOVES when a wave
    # merges.  Same reasoning as seed_source.json (see _assert_seedable): a
    # HEAD-derived fact must not live in the manifest, or every resume after a
    # merge would refuse itself.  So the manifest records the seats as they
    # are BEFORE the constraint is appended, and the constraint itself is
    # recorded in its own sibling file.
    manifest_configs = {role: dataclasses.asdict(cfg)
                        for role, cfg in sorted(configs.items())}

    # Spread gate: read the RSI merge history (READ ONLY — git log never
    # touches the working tree) and turn it into a hard constraint on the
    # Phase-1 curriculum seat.  Without it every wave lands in the same
    # package: all three recorded RSI merges touched packages/dsh-plugin
    # only, and the production line itself has zero changes to this day.
    spread_config = spread.load_config()
    spread_state = spread.build_spread_state(usine_dir, spread_config)
    spread_applied = _apply_spread_constraint(
        configs, phase=args.phase, state=spread_state, config=spread_config)

    # Latency preflight: READ ONLY and zero cost (it sends no LLM request).
    # It reads the per-seat elapsed time the engine already wrote down in past
    # runs and compares it with this wave's planned slices — a slice absorbs
    # variance only so far, and the gateway's first-response latency has been
    # measured at 50.6s / 108.2s / 138.7s / 322s / >300s.
    latency_report = latency_budget.assess(
        runs_root=Path(args.root), slices=budget_plan.slices,
        applied=applied_seat_wall,
        allow_high_latency=bool(args.allow_high_latency))

    ctx_budget = _context_budget_check(configs)
    if not budget_plan.fits and not args.time_budget_allow_over:
        raise RuntimeError(
            "planned time budget does not fit the run ceiling: planned "
            f"{budget_plan.planned_total_secs}s (seats "
            f"{budget_plan.slices}, overhead reserve "
            f"{budget_plan.overhead_reserve_secs}s) > ceiling "
            f"{budget_plan.ceiling_secs}s. Raise --run-ceiling-secs or "
            "narrow the wave; pass --time-budget-allow-over only if you "
            "accept the run may exceed its ceiling.")
    endpoints = _resolve_endpoints(
        Path(args.llm_config), set(lineup["used_models"]))
    # The engine's default-endpoint fallback (used only for a slug with no
    # per-slug mapping — waves map every needed slug fail-closed) must also
    # read the unified config, never théâtre/.env or any other source.
    os.environ.setdefault("RSIAGENT_ENV_FILE", str(Path(args.llm_config)))
    # bfs8 postmortem: a 128k-token context (one recon program printed 153k
    # characters) pushed every later round into the gateway's slow tail, where
    # the SDK's default 120s read timeout killed LEGITIMATE in-flight
    # responses twice per call, burning 480s of a 400s slice on retries.
    #   180s covered that case, but bfs12 measured the cost of a HANGING
    # provider instead: the engine's 4-attempt transport loop burned 891s of
    # run's time limit on one call (4 x 180s + backoff).  Provider downtime is
    # EXCLUDED from the seat budget (loop.py moves the work origin forward),
    # so it is charged only to the run ceiling — and 891s is 59% of 1500s.
    #   120s still covers every measured legitimate call (3-60s, and 89s on
    # the gateway's cold instance) with margin, while bounding one hanging
    # call to ~570s.
    os.environ.setdefault("RSIAGENT_LLM_TIMEOUT_SECS", "120")

    gate_argv = tuple(str(item) for item in args.gate_argv)
    merge_config = wave_merge.UsineMergeConfig(
        usine_dir=str(usine_dir), gate_argv=gate_argv,
        gate_timeout=float(args.gate_timeout),
        tag_prefix=tag_prefix)
    # Fail closed on a dirty/foreign usine repository before anything else.
    # Phase 1 MERGES into that repository, so it takes the strict merge-safety
    # gate.  Phase 2 (the DRS) never merges — its serial core emits
    # PROJECT_CLOSED, not PHASE1_WAVE_COMPLETED, so the wave-merge sink never
    # fires — and its seed is a `git archive HEAD` that never reads the
    # worktree.  So the DRS asks for what it needs (a resolvable HEAD) and
    # RECORDS the worktree state instead of refusing on it: the manifest
    # then says which commit the DRS seeded from and what the worktree
    # carried at that moment.
    ctx = wave_merge._repo_context(usine_dir)
    if args.phase == "2":
        seed_source = wave_merge._assert_seedable(ctx, usine_dir)
    else:
        wave_merge._assert_preconditions(ctx, usine_dir)
        seed_source = {"head": wave_merge._git(
            ["rev-parse", "HEAD"], cwd=ctx["toplevel"]
        ).stdout.decode("utf-8", "replace").strip(),
            "worktree_dirty_tracked": [],
            "index_has_staged_changes": False,
            "note": "Phase 1 merges: the strict merge-safety gate applies"}

    # The distribution must be 8-gram-disjoint from every audited surface
    # BEFORE anything is written or spent (fail-closed on both entrypoints;
    # no endpoints file, no run root, no corpus has been touched yet).
    fence = _check_distribution_fences(distribution, theatre, usine_dir)

    # Gate-runnability preflight, same fail-closed logic on both
    # entrypoints: a gate that cannot run AT ALL must die here, before a
    # single token is spent — a red gate at merge time is a data-level
    # gate_rejected (silent total candidate loss).  The read-only
    # --preflight report never installs; --execute fails closed on the
    # same section and may auto-install only with explicit --gate-install.
    gate_pre = gate_preflight(
        usine_dir, gate_argv,
        allow_install=bool(args.gate_install) and not args.preflight)

    # 记忆快照历史必须自洽再开跑：wave tag / 快照目录撞名曾经静默地把两条
    # run root 的记忆树写进同一个 wave-001（盘上 8 个文件、manifest 只描述
    # 3 个）。历史已经坏了的时候继续往上叠，会让「这一波的记忆是哪来的」
    # 永久不可考——所以这里 fail-closed，修法是显式跑一次审计命令。
    snapshot_root = wave_merge.memory_snapshot_root(ctx, merge_config)
    snapshot_audit = (wave_merge.verify_memory_snapshots(snapshot_root)
                      if snapshot_root is not None else None)
    snapshot_problems = (snapshot_audit or {}).get("problems") or []

    corpus_path = run_root / "corpus_shingles.json"
    corpus_mode = "resume" if args.resume_completed_boundary else "fresh"

    if args.preflight:
        seed_preview = _build_seed(usine_dir, write_to=None)
        if not gate_pre["ok"]:
            status = "gate_preflight_failed"
        elif snapshot_problems:
            status = "memory_snapshot_audit_failed"
        else:
            status = "ready"
        payload = {
            "status": status,
            "phase": phase_label,
            "study_design": (
                "target_conditioned_adaptation"
                if args.target_query_conditioned
                else "held_out_generalization"),
            "result_root": str(run_root),
            "project_budget": args.project_budget,
            "memory_checkpoints": list(checkpoints),
            "parallel_waves": True,
            "max_parallel": args.max_parallel,
            "wave_width_agent_owned": True,
            "branch_memory_snapshot_isolated": True,
            "memory_writes_serialized": True,
            "curriculum_may_stop_early": True,
            "curriculum_terminal_token": "SATURATED",
            "actor_agent": configs["actor"].model,
            "memory_actor_agent": configs["memory_actor"].model,
            "verifier_agent": configs["verifier_control"].verifier_model,
            "escalated_actor": lineup["esc_actor"],
            "escalated_verifier": lineup["esc_verifier"],
            "curriculum_agent": configs["curriculum"].model,
            "curriculum_eyes": configs["curriculum"].vision_model,
            "verifier_execution_mode":
                configs["verifier_control"].verifier_execution_mode,
            "verifier_candidate_surface":
                "actual_candidate_with_actor_private_artifacts_hidden",
            "verifier_pre_actor_orientation": False,
            "official_evaluator_imported": False,
            "official_evaluator_calls": 0,
            "distribution_path": str(distribution_path),
            "distribution_sha256": _sha256(distribution_path),
            "distribution_fence": fence,
            "corpus_mode": corpus_mode,
            "corpus_path": str(corpus_path),
            "corpus_lifetime": (
                "fixed: distribution shingles only; never extended mid-run "
                "(stock Phase-1 feedback replays prior project texts "
                "verbatim into later Curriculum prompts)"),
            "usine_dir": str(usine_dir),
            "usine_repo_toplevel": ctx["toplevel"],
            "usine_repo_prefix": ctx["prefix"] or "(repo root)",
            "seed_source": seed_source,
            "seed_preview": seed_preview,
            "memory_seed": memory_seed_info,
            "gate": {"argv": list(gate_argv),
                     "timeout": float(args.gate_timeout)},
            "gate_preflight": gate_pre,
            "memory_snapshot_audit": snapshot_audit,
            "llm_endpoints": {
                "config": str(Path(args.llm_config).expanduser()),
                "resolved": {slug: {"base_url": True, "api_key": True}
                             for slug in sorted(endpoints)},
            },
            "publish_boundary": [
                "vm facade refuses publish-shaped programs before execution",
                "guest-home USERPROFILE pin (no live platform profiles)",
                "offline-only gate; corpus leakage audits",
            ],
            "time_budget": {
                **budget_plan.to_dict(),
                "applied_seat_wall_clock_secs": applied_seat_wall,
                "stop_at": "complete-wave boundary",
                "stop_status": time_budget.TIME_BUDGET_EXHAUSTED,
            },
            "context_budget": ctx_budget,
            "spread": {
                **spread_state,
                "constraint": spread_applied,
            },
            "latency_preflight": latency_report,
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0 if (gate_pre["ok"] and ctx_budget["ok"]
                     and not _latency_blocks(latency_report)
                     and not snapshot_problems) else 1

    expected_ack = EXECUTE_ACK if args.phase == "1" else EXECUTE_ACK_DRS
    if args.execute != expected_ack:
        raise RuntimeError(f"--execute must equal {expected_ack}")
    if not gate_pre["ok"]:
        raise RuntimeError(
            "gate preflight failed — a gate that cannot run would silently "
            "destroy every merged candidate at verify time (fix the "
            "toolchain, or pass --gate-install for a missing tree): "
            + "; ".join(gate_pre["errors"]))
    if snapshot_problems:
        raise RuntimeError(
            "memory snapshot audit failed — the repository's snapshot history "
            "does not match its manifests, so a new wave's memory could not be "
            "told apart from an older run's (fix the snapshot history first; "
            "audit with `python3 garage/wave_merge.py "
            "verify-memory-snapshots`): "
            + "; ".join(f"{p['path']}: {p['kind']} ({p['detail']})"
                        for p in snapshot_problems))
    if not ctx_budget["ok"]:
        raise RuntimeError(
            "context budget check failed — a seat whose own declarations "
            "contradict each other will hit HTTP 400 mid-wave, long after the "
            "run has burned its time budget (fix the role yaml): "
            + "; ".join(ctx_budget["findings"]))
    if _latency_blocks(latency_report):
        raise RuntimeError(
            "latency preflight refused the run — the measured per-seat wall "
            "clock from past runs exceeds this wave's planned slice, and a "
            "slice absorbs variance only so far (one worst-case gateway round "
            "trip has been measured at 50.6s / 108.2s / 138.7s / 322s / >300s, "
            "and a stalled request is charged to the seat's time budget). "
            "Lower the seat's reasoning_effort, move the seat to another "
            "endpoint, or raise --run-ceiling-secs; pass "
            "--allow-high-latency to run anyway (the risk is recorded in the "
            "manifest). Details: " + latency_report["reason"])

    if (run_root.exists() and any(run_root.iterdir())
            and not args.resume_completed_boundary):
        raise RuntimeError(
            "usine Phase-1 root is nonempty; preserve it and use a new name")
    if args.resume_completed_boundary and not run_root.is_dir():
        raise RuntimeError("usine Phase-1 resume root does not exist")
    run_root.mkdir(parents=True, exist_ok=True)
    events_path = run_root / "events.jsonl"

    # Credentials: generated OUTSIDE every repository, before any LLM call.
    endpoints_path = run_root / "endpoints.json"
    _write_json_atomic(endpoints_path, endpoints)
    os.environ["RSIAGENT_LLM_ENDPOINTS_FILE"] = str(endpoints_path)
    log.info("endpoints map written for %d model slug(s) (values never "
             "logged)", len(endpoints))

    # Corpus: fresh builds from the distribution; resume merges pending
    # waves first, then requires the corpus to equal a fresh rebuild from
    # the distribution (the corpus is fixed for the whole run).
    if args.resume_completed_boundary:
        grams = usine_hooks.load_corpus(corpus_path)
        if grams != usine_hooks._shingles(distribution):
            raise RuntimeError(
                "resumed usine corpus does not equal a fresh rebuild from "
                "the distribution (corpus rewrite or distribution drift)")
        reports = wave_merge.merge_pending_waves(str(run_root), merge_config)
        if reports:
            log.info("resume merged %d pending wave(s)", len(reports))
            # Merged candidates moved HEAD: re-clear the fence against the
            # new tree before the next wave captures from it.
            _check_distribution_fences(distribution, theatre, usine_dir)
    else:
        usine_hooks.build_corpus(corpus_path, [distribution])

    manifest = {
        "schema_version": 1,
        "kind": "usine_production_line_rsi_phase1",
        "phase": phase_label,
        "study_design": (
            "target_conditioned_adaptation"
            if args.target_query_conditioned else "held_out_generalization"),
        "result_root": str(run_root),
        "project_budget": args.project_budget,
        "memory_checkpoints": list(checkpoints),
        "parallel_waves": True,
        "max_parallel": args.max_parallel,
        "wave_width_agent_owned": True,
        "branch_memory_snapshot_isolated": True,
        "memory_writes_serialized": True,
        "curriculum_may_stop_early": True,
        "curriculum_terminal_token": "SATURATED",
        "usine_dir": str(usine_dir),
        "gate_argv": list(gate_argv),
        "gate_timeout": float(args.gate_timeout),
        "merge_tag_prefix": merge_config.tag_prefix,
        "merge_commit_scope": merge_config.commit_scope,
        "distribution_path": str(distribution_path),
        "distribution_sha256": _sha256(distribution_path),
        "corpus_path": str(corpus_path),
        "corpus_sha256": _sha256(corpus_path),
        "corpus_resume_check": "equal_to_distribution_rebuild",
        "seed_source": "git_archive_head_prefix",
        "seed_cache_key": "guest_scratch",
        "memory_seed": memory_seed_info,
        "merge_drs": bool(args.merge_drs),
        "time_budget": {
            **budget_plan.to_dict(),
            "applied_seat_wall_clock_secs": applied_seat_wall,
            "stop_at": "complete-wave boundary",
            "stop_status": time_budget.TIME_BUDGET_EXHAUSTED,
        },
        "context_budget": ctx_budget,
        **_latency_manifest_entry(latency_report),
        "configs": {
            role: {
                "path": str(role_paths[role]),
                "sha256": _sha256(role_paths[role]),
                "effective": manifest_configs[role],
            }
            for role in sorted(manifest_configs)
        },
    }
    manifest = json.loads(json.dumps(
        manifest, ensure_ascii=False, sort_keys=True))
    manifest_path = run_root / "manifest.json"
    if args.resume_completed_boundary:
        try:
            existing = json.loads(
                manifest_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, ValueError, TypeError) as exc:
            raise RuntimeError(
                "usine resume manifest is unreadable") from exc
        if _resume_manifest_key(existing) != _resume_manifest_key(manifest):
            raise RuntimeError(
                "usine resume protocol/config manifest drifted")
    else:
        _write_json_atomic(manifest_path, manifest)

    # The seed's provenance is an audit artifact, NOT part of the resume
    # gate: the manifest must stay byte-identical across a resume, and the
    # commit the run seeded from moves when a wave merges.  So it goes to
    # its own file next to the manifest.
    _write_json_atomic(run_root / "seed_source.json", {
        "phase": phase_label,
        "head": seed_source["head"],
        "worktree_dirty_tracked": seed_source["worktree_dirty_tracked"],
        "index_has_staged_changes": seed_source["index_has_staged_changes"],
        "note": seed_source["note"],
    })

    # The spread gate's own audit trail, beside the manifest for the same
    # reason seed_source.json sits beside it: the constraint is derived from
    # the git HEAD, and HEAD moves when a wave merges — so it must stay out of
    # the manifest (the resume gate compares that byte for byte).  The file
    # records what the curriculum seat was actually told.
    _write_json_atomic(run_root / "spread_state.json", {
        "phase": phase_label,
        "state": spread_state,
        "constraint": spread_applied,
        "note": "read-only: derived from the git history of the improved tree",
    })

    hooks = usine_hooks.hooks_for(corpus_path)
    seed_state = {"usine_dir": str(usine_dir), "run_root": str(run_root),
                  "cache": {}}
    hooks.capture_project = _seeded_capture(hooks.capture_project, seed_state)
    # The DRS's serial core RESETS the guest between seats, which takes the
    # seeded tree with it; the capture seam re-seeds, and this guard proves
    # the replay handed the Actor a real repository before it spends a
    # single token looking for one.
    hooks.replay_project = _baseline_guarded_replay(hooks.replay_project,
                                                     seed_state)
    vm_factory = usine_hooks.publish_blacklist_vm_factory(
        guest_env.worktree_vm_factory())
    # Seed at VM creation (see _harness_staging_vm_factory): the Curriculum
    # must SEE the repository it authors projects against.  Without this it
    # spends entire max-reasoning round trips rediscovering an empty guest.
    vm_factory = _harness_staging_vm_factory(vm_factory, seed_state, seed=True)

    def logger(event_type, **kwargs):
        _append_event(events_path, event_type, **kwargs)

    sink = wave_merge.wave_merge_event_sink(
        str(run_root), merge_config, inner=logger)

    # The deadline starts HERE, after preflight and manifest writing, so the
    # ceiling covers the spend (wave loop + merge + memory install) rather
    # than the setup.  Both engines stop at complete-project boundaries via
    # project_budget; this guard is what turns "the budget ran out" into a
    # recorded, first-class outcome instead of a hang.
    deadline = time_budget.WaveDeadline(budget_plan)
    log.info("time budget armed: %s", deadline.budget_note())
    _append_event(events_path, "TIME_BUDGET_ARMED", status="in_progress",
                  state={},
                  payload=budget_plan.to_dict())

    # A wave that would start after the ceiling is refused up front rather
    # than begun and abandoned mid-flight.  project_budget=0 makes the
    # engine return budget_exhausted at the first boundary check, which is
    # the only lever the stock loop exposes for "stop now, cleanly".
    # The DRS baseline (what its memory delta is measured against) is set
    # in the Phase-2 branch below; Phase 1 has no DRS delta.
    drs_memory_baseline: Path | None = None
    if args.phase == "2":
        # DRS is only meaningful over memory that already exists (paper 2.2:
        # the deep wave drills gaps the breadth wave exposed).  Refuse an
        # empty baseline rather than letting Phase 2 degenerate into a second
        # breadth wave wearing a DRS label.
        #
        # The baseline is the Phase-1 memory tree by default.  An explicit
        # --memory-seed REPLACES it: that is how a second DRS deepens the
        # memory the FIRST DRS deepened, instead of re-deepening the
        # shallower Phase-1 tree.  Whatever the baseline is, it is what the
        # delta below is measured against — the seed and the baseline are
        # the same directory on purpose, so "what grew" stays answerable.
        source_memory = (memory_seed if memory_seed is not None
                         else _phase1_memory_dir(args.root, args.run_name))
        if not source_memory.is_dir() or not any(
                candidate.is_file() for candidate in source_memory.rglob("*")):
            raise RuntimeError(
                f"--phase 2 deepens memory that already exists, but "
                f"{source_memory} holds no files. "
                + ("Point --memory-seed at a memory tree."
                   if memory_seed is not None else
                   "Run --phase 1 to completion first: a DRS run over empty "
                   "memory would prove nothing about deep recursion."))
        seeded_files = sum(1 for candidate in source_memory.rglob("*")
                           if candidate.is_file())
        log.info("DRS seeded from %s: %d file(s)", source_memory, seeded_files)
        _install_seed_memory(source_memory, run_root / "memory")
        drs_memory_baseline = source_memory

        # DRS wiring, checked BEFORE any token is spent.  The serial core
        # (explore/practice_loop.py) takes the Verifier CONTROL profile in
        # `agentic_verifier_cfg` — the profile that names the Verifier AGENT
        # config in `agentic_verifier_config` and carries the private-path
        # quarantine.  Phase 1 passes that control profile; the DRS path used
        # to pass the Verifier AGENT profile instead, which has no
        # `agentic_verifier_config` key, so the core refused the inspection
        # AFTER the Actor had already burned its whole budget (bfs16f,
        # 2026-10-20: 1158s spent, candidate produced, then
        # "Phase-1 Agentic Verifier control config is missing").  A wiring
        # gap must cost a preflight, not a twenty-minute run.
        _check_drs_wiring(configs)

        # DRS (paper 2.2): sequential deep recursion over the memory Phase 1
        # produced.  evolve_practice is the stock SERIAL core — one project at
        # a time, curriculum_review stopping, each verified experience entering
        # memory before the next task.  It takes a single VM rather than the
        # wave factory, which is exactly the paper's BRS-parallel / DRS-serial
        # split.
        from explore.practice_loop import evolve_practice
        desktop, drs_vm = vm_factory()
        try:
            result = evolve_practice(
                drs_vm, root=str(run_root),
                target_direction=distribution,
                actor_cfg=configs["actor"],
                verifier_cfg=configs["verifier"],
                curriculum_cfg=configs["curriculum"],
                memory_cfg=configs["memory_actor"],
                corpus_path=str(corpus_path), hooks=hooks,
                event_sink=sink,
                project_budget=args.project_budget,
                checkpoint_projects=checkpoints,
                phase1_exploration=False,
                # The CONTROL profile, not the Verifier Agent profile: the
                # serial core reads `agentic_verifier_config` (the name of
                # the Agent config) and the private-path quarantine from
                # here.  Phase 1 passes the same control profile.
                agentic_verifier_cfg=configs["verifier_control"],
                resume_completed_boundary=args.resume_completed_boundary)
        finally:
            desktop.close()
    else:
        from explore.phase1_wave import evolve_parallel_phase1
        if memory_seed is not None:
            # A wave can start ON TOP of what an earlier phase learned.
            # The engine reads the run's ``memory/`` directory as the
            # starting tree — the Curriculum seat reads it, the Actor is
            # handed it, and the branch distillation writes back into it —
            # so installing the seed here is the whole mechanism.  No
            # engine change is involved, and the engine's own ``mkdir(
            # exist_ok=True)`` leaves the seeded records alone.
            seeded = _install_seed_memory(memory_seed, run_root / "memory")
            log.info("wave seeded from %s: %d file(s)", memory_seed, seeded)
        result = evolve_parallel_phase1(
            root=str(run_root), target_direction=distribution,
            actor_cfg=configs["actor"],
            curriculum_cfg=configs["curriculum"],
            memory_cfg=configs["memory_actor"],
            verifier_control_cfg=configs["verifier_control"],
            vm_factory=vm_factory, corpus_path=str(corpus_path), hooks=hooks,
            event_sink=sink,
            project_budget=args.project_budget,
            checkpoint_projects=checkpoints,
            max_parallel=args.max_parallel,
            target_query_conditioned=args.target_query_conditioned,
            resume_completed_boundary=args.resume_completed_boundary,
            park_verified_branches=False)

    from explore.practice_loop import (
        _atomic_install_memory,
        _manifest,
        _read_memory_tree,
    )
    from explore.target_learning import _memory_tree_sha256

    memory = _read_memory_tree(result.memory_dir)
    frozen = run_root / "memory_frozen"
    _atomic_install_memory(str(frozen), memory)
    payload = {
        "schema_version": 1,
        "phase": phase_label,
        "study_design": (
            "target_conditioned_adaptation"
            if args.target_query_conditioned else "held_out_generalization"),
        "status": result.status,
        "projects": result.projects,
        "stop_reason": result.reason,
        "project_budget": args.project_budget,
        "checkpoints": list(checkpoints),
        "parallel_waves": args.phase == "1",
        "max_parallel": args.max_parallel,
        "memory_files": len(memory),
        "memory_bytes": sum(len(data) for data in memory.values()),
        "memory_manifest": _manifest(memory),
        "memory_tree_sha256": _memory_tree_sha256(memory),
        "memory_frozen_path": str(frozen),
        "official_evaluator_calls": 0,
        "time_budget": {
            **budget_plan.to_dict(),
            "applied_seat_wall_clock_secs": applied_seat_wall,
            "elapsed_secs": round(deadline.elapsed_secs, 1),
            "over_ceiling": deadline.expired,
        },
    }
    if args.phase == "2":
        # The paper's claim is that DEEP recursion keeps improving memory
        # (2.5's reuse table is entirely post-DRS).  Record the delta against
        # the baseline explicitly: without this, "the DRS run finished"
        # says nothing about whether memory actually grew.  The baseline is
        # the tree the DRS actually started from — the Phase-1 tree, or the
        # --memory-seed tree when one was given.
        from explore.target_learning import _memory_tree_sha256 as _sha
        baseline_dir = (drs_memory_baseline
                        if drs_memory_baseline is not None
                        else _phase1_memory_dir(args.root, args.run_name))
        source_memory = _read_memory_tree(str(baseline_dir))
        after = _memory_tree_sha256(memory)
        before = _sha(source_memory)
        payload["drs_delta"] = {
            "baseline_phase": 1,
            "baseline_dir": str(baseline_dir),
            "baseline_files": len(source_memory),
            "baseline_bytes": sum(len(v) for v in source_memory.values()),
            "baseline_tree_sha256": before,
            "after_tree_sha256": after,
            "files_added": max(0, len(memory) - len(source_memory)),
            "memory_changed": before != after,
            "note": (
                "paper 3.2: growth includes consolidation — memory may shrink "
                "when an integrated record replaces several older ones, so a "
                "changed tree is the signal, not a size increase"),
        }
    _write_json_atomic(run_root / "result.json", payload)
    if args.merge_drs:
        # The DRS's serial core closes its episode with PROJECT_CLOSED, not
        # PHASE1_WAVE_COMPLETED, so the wave-merge event sink never fires and
        # the candidate — verifier PASS, gate green — stays in the run root
        # where the repository never sees it.  This is the explicit switch
        # that puts it through the SAME delta / drift / gate / commit / tag
        # machinery a breadth wave goes through.
        payload["drs_merge"] = _merge_drs_into_usine(run_root, merge_config)
        _write_json_atomic(run_root / "result.json", payload)
    if deadline.expired:
        # The ceiling is the operator's contract, not a soft target: a run
        # that overran it is reported as its own status so a monitoring loop
        # can distinguish "succeeded slowly" from "stopped by the clock".
        payload["status"] = time_budget.TIME_BUDGET_EXHAUSTED
        payload["stop_reason"] = deadline.stop_reason()
        _write_json_atomic(run_root / "result.json", payload)
        _append_event(events_path, "TIME_BUDGET_EXHAUSTED",
                      status="in_progress", state={}, payload={
                          "elapsed_secs": round(deadline.elapsed_secs, 1),
                          "ceiling_secs": budget_plan.ceiling_secs,
                      })
    print("\n=== USINE PHASE 1 RESULT " + json.dumps(payload, sort_keys=True))
    if payload["status"] == time_budget.TIME_BUDGET_EXHAUSTED:
        return 3
    if args.merge_drs and not payload["drs_merge"]["ok"]:
        # The run itself may have succeeded; the MERGE did not.  Exit 4 says
        # exactly that, so a monitoring loop does not read "the DRS worked"
        # out of a payload whose candidate never reached the repository.
        return 4
    return 0 if result.status in {"saturated", "budget_exhausted"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
